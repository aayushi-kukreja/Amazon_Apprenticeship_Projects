package database;
	import java.sql.Connection;
	import java.sql.DriverManager;

	public class ConnectionProvider {
			
		static Connection con;
		public static Connection CreateC() {
			try {
				
				Class.forName("com.mysql.jdbc.Driver");
				
				String user = "root";
				String password = "MyPassword123@123";
				String url = "jdbc:mysql://localhost:3306/a";
				con = DriverManager.getConnection(url, user, password);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return con;
		}
}
