import java.sql.SQLException;
import java.util.Date;
import java.util.Scanner;

import database.Info_Shares;
import database.Info_Transactions;
import database.Info_User;
import implementation.DepositMoney;
import implementation.Create_Account;
import implementation.DisplayAccDetails;
import implementation.Login;
import implementation.UserId;

public class Main {

	public static void main(String[] args) {

		System.out.println("Welcome to D-MAT App ");
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("Press 1 to Create New Account");
			System.out.println("Press 2 to LOGIN");
			System.out.println("Press 3 to EXIT");

			// Now asking user to select one option
			int xyz = sc.nextInt();
			if (xyz == 1) {
				System.out.println("Account number");
				int accno = sc.nextInt();

				System.out.println("Username");
				String username = sc.next();

				System.out.println("Enter amount you want to add in your account");
				double money = sc.nextDouble();
				Create_Account ac = new Create_Account(accno, username, money);
				boolean ans = Info_User.createAccToDB(ac);

			} else if (xyz == 2) {
				// remaining options
				// 0 – Quit
				// 1 – Display Demat account details
				// 2 – Deposit Money
				// 3 – Withdraw Money
				// 4 – Buy transaction
				// 5 – Sell transaction
				// 6 – View transaction report

				System.out.println("Account number ");
				int acc = sc.nextInt();

				Login la = new Login(acc);
				boolean ans = Info_User.loginToDB(la);
				if (ans) {
					while (true) {
						System.out.println("Press 1 to Display D-MAT Account details");
						System.out.println("Press 2 to Deposit Money");
						System.out.println("Press 3 to Withdraw Money");
						System.out.println("Press 4 to Buy a share");
						System.out.println("Press 5 to Sell a share");
						System.out.println("Press 6 View Transaction Report");
						System.out.println("Press 0 to Go to the Main Menu");

						
						int s = sc.nextInt();
						if (s == 1) {
							System.out.println("Please enter the account number");
							int accId = sc.nextInt();
							// Display
							DisplayAccDetails dd = new DisplayAccDetails(accId);
							Info_User.displayDetails(dd);

						} else if (s == 2) {

							System.out.println("Enter the amount you want to deposit to your account");
							double money = sc.nextDouble();
							System.out.println("Please confirm your account number ");
							int accno = sc.nextInt();
							Info_User ud = new Info_User();
							boolean a = Info_User.addMoneytoDB(accno, money);
							if (a) {
								System.out.println("Deposited Successfuly");
							}

						} else if (s == 3) {
							
							Scanner a = new Scanner(System.in);
							System.out.println("Please Enter the Amount you want to Withdraw from Account.");
							double withdrawalAmount = a.nextDouble();
							System.out.println("Please confirm your Account number");
							int accno = a.nextInt();

							Info_User ud = new Info_User();
							boolean success = Info_User.withdrawMoneyFromDB(accno, withdrawalAmount);
							if (success) {
								System.out.println("Withdrawal successful");
							} else {
								System.out.println("Withdrawal failed");
							}
						} else if (s == 4) {
							Info_Shares.share_details();

							System.out.println("Please enter userId");
							int userId = sc.nextInt();
							System.out.println("Please enter shareId");
							int shareId = sc.nextInt();
							System.out.println("Please enter how many shares you want to buy");
							int numberOfShares = sc.nextInt();
							try {
								String anss = Info_User.BuyTransactionFromDB(userId, shareId, numberOfShares);
								if (anss != null) {
									System.out.println("Transaction SUCCESSFUL");
								} else {
									System.out.println("Something Went Wrong");
								}
							} catch (SQLException e) {
								
								e.printStackTrace();
							}

						} else if (s == 5) {
							// sell
							System.out.println("Please enter userId");
							int userId = sc.nextInt();
							System.out.println("Please enter shareId");
							int shareId = sc.nextInt();
							System.out.println("Please enter the number of shares you want to sell");
							int numberOfShares = sc.nextInt();
							try {
								boolean anss = Info_User.SellTransactionFromDB(userId, shareId, numberOfShares);
								if (anss) {
									System.out.println("Transaction SUCCESSFUL");
								} else {
									System.out.println("Something Went Wrong");
								}
							} catch (SQLException e) {

								e.printStackTrace();
							}
							Info_Shares.shareDetails();
						} else if (s == 6) {

							System.out.println("Press 1 to Print Transaction Report As per Date ");
							System.out.println("Press 2 to Print Transaction Report As per Share Id ");

							int w = sc.nextInt();
							if (w == 1) {

								try {
									Info_Transactions.transactionByDates();
								} catch (ClassNotFoundException | SQLException e) {
								}
							} else if (w == 2) {

								try {
									Info_Transactions.transationByUsers();
								} catch (ClassNotFoundException | SQLException e) {

									e.printStackTrace();
								}
							}

						} else if (s == 0) {
							break;
						} else {
							System.out.println("Please choose the correct option\n");
						}
					}
				} else {
					System.out.println("Please Enter correct account number");
				}
			} else if (xyz == 0) {
				break;
			} else {
				System.out.println("Please Enter correct account number");

			}

		}
		System.out.println("Thank you for using D-MAT APP");
	}

}
