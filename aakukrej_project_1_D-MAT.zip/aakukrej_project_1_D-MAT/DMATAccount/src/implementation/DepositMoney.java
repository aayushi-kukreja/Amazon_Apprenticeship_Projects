package implementation;

public class DepositMoney {
			private double money;
			private int accountNumber;
			public DepositMoney(double money) {
				super();
				this.money = money;
			}
			public DepositMoney(double money, int accountNumber) {
				super();
				this.money = money;
				this.accountNumber = accountNumber;
			}
			public DepositMoney() {
				super();
				// TODO Auto-generated constructor stub
			}
			public double getMoney() {
				return money;
			}
			public void setMoney(double money) {
				this.money = money;
			}
			public int getAccountNumber() {
				return accountNumber;
			}
			public void setAccountNumber(int accountNumber) {
				this.accountNumber = accountNumber;
			}
			@Override
			public String toString() {
				return "AddMoney [money=" + money + ", accountNumber=" + accountNumber + "]";
			}
			
			
}
