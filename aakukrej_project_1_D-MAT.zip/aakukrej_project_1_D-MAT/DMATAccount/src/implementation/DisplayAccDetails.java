package implementation;

public class DisplayAccDetails {
		
	private int accNo;
	private int accId;
	public DisplayAccDetails(int accNo, int accId) {
		super();
		this.accNo = accNo;
		this.accId = accId;
	}
	
	public DisplayAccDetails(int accId) {
		super();
		this.accId = accId;
	}
	public DisplayAccDetails() {
		super();
	}
	@Override
	public String toString() {
		return "DisplayDetails [accNo=" + accNo + ", accId=" + accId + "]";
	}
	public int getAccNo() {
		return accNo;
	}
	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}
	public int getAccId() {
		return accId;
	}
	public void setAccId(int accId) {
		this.accId = accId;
	}
	
}
