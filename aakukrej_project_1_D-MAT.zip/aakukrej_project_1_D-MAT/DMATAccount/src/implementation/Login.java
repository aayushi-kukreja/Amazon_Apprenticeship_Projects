package implementation;

public class Login {
		
		private int accountNumber;

		public Login(int accountNumber) {
			super();
			this.accountNumber = accountNumber;
		}

		public int getAccountNumber() {
			return accountNumber;
		}

		public void setAccountNumber(int accountNumber) {
			this.accountNumber = accountNumber;
		}

		public Login() {
			super();
		}

		@Override
		public String toString() {
			return "LoginAccount [accountNumber=" + accountNumber + "]";
		}
		
}
