package implementation;

public class UserId {
private int userid;

public UserId() {
	super();
	this.userid = userid;
}

public int getUserid() {
	return userid;
}

public void setUserid(int userid) {
	this.userid = userid;
}

@Override
public String toString() {
	return "UserId [userid=" + userid + "]";
}



}
