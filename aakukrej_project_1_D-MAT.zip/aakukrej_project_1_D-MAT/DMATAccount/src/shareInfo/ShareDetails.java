package shareInfo;

public class ShareDetails {
	private int userId;
	private String share_Name;
	private int total_No_Of_Shares;
	private int share_Id;
	private int valueOfShares;

	public ShareDetails(String shareName, int totalShares, int valueOfShares) {
		super();
		this.share_Name = shareName;
		this.total_No_Of_Shares = totalShares;
		this.valueOfShares = valueOfShares;
	}

	public ShareDetails(int userId, String shareName, int shareId, int valueOfShares) {
		super();
		this.userId = userId;
		this.share_Name = shareName;
		this.share_Id = shareId;
		this.valueOfShares = valueOfShares;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getShareName() {
		return share_Name;
	}

	public void setShareName(String shareName) {
		this.share_Name = shareName;
	}

	public int getNoOfShares() {
		return share_Id;
	}

	public void setNoOfShares(int noOfShares) {
		this.share_Id = noOfShares;
	}

	public int getValurOfShares() {
		return valueOfShares;
	}

	public void setValurOfShares(int valueOfShares) {
		this.valueOfShares = valueOfShares;
	}

	@Override
	public String toString() {
		return "ShareDetails [userId=" + userId + ", shareName=" + share_Name + ", ShareId=" + share_Id
				+ ", valueOfShares=" + valueOfShares + "]";
	}
}
