import operations.AppDriver;

/**
 * Driver is the Main Class for the application.
 * Application is started by calling initiate function of AppDriver Class
 * **/

public class Driver {

  public static void main(String[] args) throws Exception {
    AppDriver appDriver = new AppDriver();
    appDriver.initiate();
}
  }

















