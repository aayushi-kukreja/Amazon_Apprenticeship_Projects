package Functionality;

import java.util.Scanner;

import Administration.UserExecutor;
import exceptionHandling.AppException;
import exceptionHandling.UserException;
import resources.ShopInformation;
import resources.User;

/**
 * This class is implements the sign-in/sign-up/account control page
 * functionality for the USER. It is an extension of BaseOperation class.
 *
 * Existing Users can login with their employee id and password - If login is
 * successful, they are routed to the USER homepage of the application. - If
 * login is unsuccessful even after 3 tries, they are routed back to the USER
 * Account Control page.
 *
 * New users can create a account by entering requested credentials. - If create
 * account is successful, they can proceed to login. - If create account is
 * unsuccessful, they are routed back to the USER Account Control page.
 **/

public class UserLoginFunction extends BaseOperation {

    private final static int maxLoginTries = 5;
    private static int loginTries = 0;

    public boolean showMenu() throws AppException {
	boolean exitCode = false;
	String choice = "";
	Scanner sc = OperationFactory.getScannerInstance();

	while (!exitCode) {
	    System.out.println("\u001B[36m" + "\nWelcome to user's Login/Sign-up Page" + "\u001B[0m");
	    System.out.println("\u001B[32m" + "\n1. Login " + "\n2. Sign Up" + "\u001B[0m" + "\u001B[31m"
		    + "\n0. Exit\n" + "\u001B[0m");

	    choice = sc.next();

	    switch (choice) {
	    case "1":
		try {
		    setLoginDetails();
		} catch (UserException e) {
		    System.out.println("Returning to previous menu as the below exception has occurred.");
		    System.out.println(e.getMessage());
		}
		break;
	    case "2":
		try {
		    createAccount();
		} catch (UserException e) {
		    System.out.println("Returning to previous menu as the below exception has occurred.");
		    System.out.println(e.getMessage());
		}
		break;
	    case "0":
		exitCode = true;
		break;

	    default:
		System.out.println("Please Enter Valid Option");
	    }
	}

	System.out.println("Returning to Main Menu");

	return true;
    }

    // Creates a User Account and sends to login page
    private void createAccount() throws AppException, UserException {
	System.out.println("\nCreate your new User account");
	System.out.println("\nPlease Enter the below details as prompted and Press Enter to confirm entry."
		+ "\nPress Enter Twice to return to Previous Menu. ");

	System.out.println("\n Employee ID [9 Digit Number]: \n");
	int employeeId = this.getUserId();

	boolean userAlreadyExists = UserExecutor.getInstance().isValidUserId(employeeId);

	if (userAlreadyExists) {
	    System.out.println("User Id for " + employeeId + " already exists\n");
	}

	if (!userAlreadyExists) {

	    System.out.println(
		    "\n ENTER USERNAME : \n" + "[Should be of at least 5 characters, contain only letters and digits]");
	    String username = this.getUsername();

	    System.out.println("\n ENTER First Name : \n");
	    String firstName = this.getFirstName();

	    System.out.println("\n ENTER Last Name : \n");
	    String lastName = this.getLastName();

	    System.out.println("\n ENTER Email Address : \n");
	    String email = this.getEmail();

	    System.out.println("\n ENTER Password : \n"
		    + "[Should be of at least 8 characters, contain only letters and digits and "
		    + "must contain at least 2 digits]");
	    String password = this.getPassword();

	    System.out.println("\n Confirm Password : \n" + "[Should be the same value as entered before]");
	    String confirmedPassword = this.getConfirmedPassword(password);

	    User user = ShopInformation.getInstance().getUserInstance(employeeId, username, firstName, lastName, email,
		    confirmedPassword);

	    // userId, username, firstName, lastName, email, userPassword
	    // System.out.println( UserManager.getInstance().create(user) );
	    UserExecutor.getInstance().createUser(user);

	    System.out.println("Your Account with User ID : " + user.getUserId() + " has been created ! \n");
	    System.out.println("Please Login with your User ID and Password below : \n");

	    setLoginDetails();
	}
    }

    // If the user and password combination exist, redirect to UserOperations
    private void login(String username, String password) throws AppException, UserException {

	if (UserExecutor.getInstance().isValidUserPassword(username, password)) {

	    if (!UserExecutor.getInstance().isValidUserStatus(username)) {
		System.out.println("\nYour account is currently deactivated. "
			+ "\nPlease contact an administrator for further assistance. \n");
		showMenu();
	    }
	    System.out.println("\u001B[32m" + "User Login Successful!" + "\u001B[0m");
	    OperationFactory.getUserOperationInstance().showMenu(username);

	} else {
	    System.out.println("\nUnable to load account with entered credentials. "
		    + "\nPlease make sure that the entered credentials are correct \n");
	    setLoginDetails();
	}

    }

    private boolean setLoginDetails() throws AppException, UserException {
	loginTries += 1;
	System.out.println("\u001B[31m" + "Enter username : \n" + "\u001B[0m");
	String username = this.getUsername();

	System.out.println("\u001B[31m" + "Enter password : \n" + "\u001B[0m");
	String password = this.getPassword();

	if (loginTries > maxLoginTries) {
	    System.out.println("Maximum Login Tries Exceeded! \n Returning to Home.");

	    loginTries = 0;
	    return false;
	}
	login(username, password);

	return true;
    }
}
