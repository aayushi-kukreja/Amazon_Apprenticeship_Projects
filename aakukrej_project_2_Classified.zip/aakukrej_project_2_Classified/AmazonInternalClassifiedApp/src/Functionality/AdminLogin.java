package Functionality;

import exceptionHandling.AppException;
import exceptionHandling.UserException;
import resources.Admin;

/**
 * This class is implements the log-in page for Admin Admin can login with their
 * Admin id and password - If login is successful, they are routed to the Admin
 * Operation page of the application. - If login is unsuccessful even after 3
 * tries, they are routed back to the application homepage.
 **/

// AdminLogin , Singleton as Only 1 ADMIN is Hard-Coded
public class AdminLogin extends BaseOperation {

    // Set Hard-Coded values of ADMIN object to variables
    private String adminID = Admin.getAdminInstance().getAdminId();
    private String password = Admin.getAdminInstance().getPassword();

    private static int loginTries = 1;
    private final static int maxLoginTries = 3;

    private static AdminLogin adminLogin;

    private AdminLogin() {
    }

    public static AdminLogin getInstance() {
	if (adminLogin == null) {
	    adminLogin = new AdminLogin();
	}
	return adminLogin;
    }

    public void showMenu() throws AppException {
	try {
	    setLoginDetails();
	} catch (UserException e) {
	    System.out.println("An issue has occurred. Please retry logging in.");
	}
    }

    private void login(String adminId, String password) throws AppException, UserException {
	if (adminId.trim().equals(this.adminID) && password.equals(this.password)) {
	    System.out.println("\u001B[32mAdmin Login Successful!\u001B[0m");
	    OperationFactory.getAdminOperationInstance().showMenu();
	} else {
	    System.out.println("Please enter correct ID and Password.[Only 3 tries are allowed] \n");
	    setLoginDetails();
	}
    }

    // Gets Admin credentials from console
    private boolean setLoginDetails() throws UserException, AppException {
	loginTries += 1;

	System.out.println("\u001B[31mEnter Login ID :\u001B[0m");
	String userId = this.getAdminId();

	System.out.println("\n\u001B[31mEnter Password :\u001B[0m");
	String password = this.getAdminPassword();

	if (loginTries > maxLoginTries) {
	    System.out.println("Maximum Login Tries Exceeded! \n Returning to Home.");

	    loginTries = 0;

	    return false;
	}

	login(userId, password);

	return true;
    }
}
