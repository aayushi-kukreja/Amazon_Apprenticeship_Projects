package Functionality;

import java.util.Scanner;

/*
 * Simple factory implementation 
 * returns new instances for all classes 
 * controls instance creation of upper layer
 */

public class OperationFactory {
    public static AdminLogin getAdminLoginInstance() {
	return AdminLogin.getInstance();
    }

    public static AdminFunction getAdminOperationInstance() {
	return new AdminFunction();
    }

    public static UserLoginFunction getUserLoginInstance() {
	return new UserLoginFunction();
    }

    public static UserOperation getUserOperationInstance() {
	return new UserOperation();
    }

    public static Scanner getScannerInstance() {
	return new Scanner(System.in); // .useDelimiter("\n")
    }

}
