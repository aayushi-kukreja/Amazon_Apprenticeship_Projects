package Functionality;

import exceptionHandling.AppException;
import exceptionHandling.UserException;
import resources.Classified;

public class UserOperation extends BaseOperation {

    public boolean showMenu(String username) throws AppException {
	boolean exitCode = false;
	while (!exitCode) {
	    System.out.println("\u001B[33m" + "Welcome to User's Operation Menu");
	    System.out.println("\nChoose an Option :" + "\u001B[0m");
	    System.out.println("\u001B[32m" + "\n1. Manage Your Profile \n" + "2. Post a Classified \n"
		    + "3. Browse Classifieds \n" + "4. Communication \n" + "5. Payment and Transaction \n" + "\u001B[0m"
		    + "\u001B[31m" + "0. Exit to Main Menu" + "\u001B[0m");
	    String choice = OperationFactory.getScannerInstance().next();
	    switch (choice) {
	    case "1":
		manageProfile(username);
		break;
	    case "2":
		try {
		    postClassified(username);
		} catch (UserException e) {
		    // print the exception message
		    this.printMenuException(e);
		}
		break;
	    case "3":
		browseClassifieds(username);
		break;
	    case "4":
		connectWithUsers(username);
		break;
	    case "5":
		paymentAndTransaction(username);
		break;
	    case "0":
		System.out.println("You have chosen to exit\n");
		exitCode = true;
		break;
	    default:
		System.out.println("Please enter a valid operation");

	    }

	}

	System.out.println("Returning to the previous menu");

	return true;
    }

    private boolean paymentAndTransaction(String username) throws AppException {

	boolean exCode = false;
	String choice = "";

	while (!exCode) {
	    System.out.println("\u001B[33m" + "\nChoose an Option\n" + "\u001B[0m");

	    System.out.println("\u001B[32m" + "1. Manage Payment Method  \n" + "2. View Transaction\n" + "\u001B[0m"
		    + "\u001B[31m" + "0. Return to User Menu" + "\u001B[0m");

	    choice = OperationFactory.getScannerInstance().next();

	    switch (choice) {
	    case "1":

		managePaymentMethod(username);

		break;

	    case "2":
		try {
		    viewTransaction(username);
		} catch (UserException e) {
		    // print the exception message
		    this.printMenuException(e);
		}
		break;

	    case "0":
		exCode = true;
		break;

	    default:
		System.out.println("Please Enter Valid Option\n");
	    }

	}
	System.out.println("Returning to previous Menu");

	return true;

    }

    private boolean viewTransaction(String username) throws AppException, UserException {

	int userId = UserManager.getInstance().getUserId(username);

	System.out.println("\nView all Transactions\n");
	TransactionManager.getInstance().viewAllTransactionByUser(userId);

	boolean exCode = false;
	String choice = "";

	while (!exCode) {
	    System.out.println("\u001B[33m" + "\nChoose an Option\n" + "\u001B[0m");

	    System.out.println("\u001B[32m" + "1. Filter by specific Date \n" + "2. Filter by Date range\n"
		    + "\u001B[0m" + "\u001B[31m" + "0. Return to User Menu" + "\u001B[0m");

	    choice = OperationFactory.getScannerInstance().next();

	    switch (choice) {
	    case "1":
		try {
		    filterBySpecificDate(username);
		} catch (UserException e) {
		    // print the exception message
		    this.printMenuException(e);
		}
		break;

	    case "2":
		try {
		    filterByDateRange(username);
		} catch (UserException e) {
		    // print the exception message
		    this.printMenuException(e);
		}
		break;

	    case "0":
		exCode = true;
		break;

	    default:
		System.out.println("Please Enter Valid Option\n");
	    }

	}
	System.out.println("Returning to previous Menu");

	return true;

    }

    private boolean filterBySpecificDate(String username) throws AppException, UserException {

	int userId = UserManager.getInstance().getUserId(username);
	System.out.println("\nEnter Specific Date");
	System.out.println("Please use the format 'YYYY-MM-DD'");
	String date = this.getDate();

	System.out.println("\n Transaction(s) made on " + date + "\n");
	TransactionManager.getInstance().viewTransactionByDate(userId, date);

	return true;
    }

    private boolean filterByDateRange(String username) throws AppException, UserException {
	int userId = UserManager.getInstance().getUserId(username);
	System.out.println("\nEnter Start Date");
	System.out.println("Please use the format 'YYYY-MM-DD'");
	String start = this.getDate();
	System.out.println("\nEnter End Date");
	System.out.println("Please use the format 'YYYY-MM-DD'");
	String end = this.getDate();

	System.out.println("\n Transaction(s) made between " + start + " and " + end + "\n");
	TransactionManager.getInstance().viewTransactionByDateRange(userId, start, end);

	return true;
    }

    private boolean managePaymentMethod(String username) throws AppException {
	// TODO Auto-generated method stub
	boolean exCode = false;
	String choice = "";

	while (!exCode) {
	    System.out.println("\nChoose an Option :\n");

	    System.out.println(
		    "1. Add a New Payment Method \n" + "2. Remove a Payment Method \n" + "0. Return to previous Menu");

	    choice = OperationFactory.getScannerInstance().next();

	    switch (choice) {
	    case "1":
		try {
		    addPaymentMethod(username);
		} catch (UserException e) {
		    // TODO Auto-generated catch block
		    this.printMenuException(e);

		}
		break;

	    case "2":
		try {
		    removePaymentMethod(username);
		} catch (UserException e) {
		    // TODO Auto-generated catch block
		    this.printMenuException(e);
		}
		break;

	    case "0":
		exCode = true;
		break;

	    default:
		System.out.println("Please Enter Valid Option\n");
	    }

	}
	System.out.println("Returning to previous Menu");

	return true;
    }

    private boolean removePaymentMethod(String username) throws UserException, AppException {
	int userId = UserManager.getInstance().getUserId(username);
	System.out.println("Your Payment Methods\n");
	PaymentManager.getInstance().retrieveAllPaymentMethodForUser(userId);
	System.out.println("\nEnter Payment ID to remove Payment Method");
	int paymentId = this.getPaymentId();
	if (!PaymentManager.getInstance().isValidPaymentMethod(paymentId, userId)) {
	    System.out.println("Invalid Payment ID");
	    return false;
	}

	PaymentManager.getInstance().deletePaymentMethod(paymentId);
	System.out.println("Payment Method removed");

	return true;
    }
    
    private boolean TESTaddPaymentMethod(String username) throws UserException, AppException {

	 int id = UserManager.getInstance().getUserId(username);
	 String paymentDetails = "";
	
	boolean exCode = false;

	while (!exCode) {
	    System.out.println("\nChoose an Option :\n");

	    System.out.println(
		    "1. Card \n" + "2. UPI \n" + "3. Digital");

	    int choice = OperationFactory.getScannerInstance().nextInt();

	    switch (choice) {
	    case 1:
		 
		 String cardDetails = this.getCardDetails();
		 paymentDetails = "Card ending in " + cardDetails.substring(cardDetails.length() - 4);
		
		 
		 PaymentAbstractFactory paf = PaymentMethodFactory.getAbstractFactory(choice);
		 
		 boolean exitCode = false;

			while (!exitCode) {
			    System.out.println("\u001B[33m" + "\nSelect Field to Update\n" + "\u001B[0m");

			    System.out.println( "1. Debit Card \n" + "2. Credit Card\n" + "3. American Express Card \n") ;

			    int ch = OperationFactory.getScannerInstance().nextInt();

			    switch (ch) {
			    case 1:
				Payments pam = paf.createPaymentMethod(ch, paymentDetails);
				pam.add(paymentDetails);

				break;
			    case 2:
				Payments pam = paf.createPaymentMethod(ch, paymentDetails);
				pam.add(paymentDetails);
			    case 3:
				try {
				    updatePassword(username);
				} catch (UserException e) {
				    this.printMenuException(e);
				}
				break;

			  
			    default:
				System.out.println("Please Enter Valid Option\n");
			    }

			}
		 
		
		
		break;

	    case 2:
		try {
		    removePaymentMethod(username);
		} catch (UserException e) {
		    // TODO Auto-generated catch block
		    this.printMenuException(e);
		}
		break;

	    case 3:
		exCode = true;
		break;

	    default:
		System.out.println("Please Enter Valid Option\n");
	    }

	}
    }

   	String paymentMethod = "";
   	if (method == "Credit Card" || method == "Debit Card") {
   	    System.out.println("Enter Card Number");
   	    String details = this.getCardDetails();
   	    paymentMethod = method + " ending in " + details.substring(details.length() - 4);
   	} else {
   	    System.out.println("Enter PayPal Email");
   	    String email = this.getEmail();
   	    int atIndex = email.indexOf("@");
   	    paymentMethod = method + " with email " + email.substring(0, 1) + "***"
   		    + email.substring(atIndex - 1, atIndex) + "***" + email.substring(email.indexOf("."));
   	}


    private boolean addPaymentMethod(String username) throws UserException, AppException {

	String method = this.getPaymentMethod();

	String paymentMethod = "";
	if (method == "Credit Card" || method == "Debit Card") {
	    System.out.println("Enter Card Number");
	    String details = this.getCardDetails();
	    paymentMethod = method + " ending in " + details.substring(details.length() - 4);
	} else {
	    System.out.println("Enter PayPal Email");
	    String email = this.getEmail();
	    int atIndex = email.indexOf("@");
	    paymentMethod = method + " with email " + email.substring(0, 1) + "***"
		    + email.substring(atIndex - 1, atIndex) + "***" + email.substring(email.indexOf("."));
	}

	int id = UserManager.getInstance().getUserId(username);

	Payment newPaymentMethod = InfoFactory.getInstance().getPaymentInstance(id, paymentMethod);
	PaymentManager.getInstance().createPayment(newPaymentMethod);

	System.out.println("Payment Method added successfully");

	return true;
    }

    private boolean manageProfile(String username) throws AppException {

	boolean exCode = false;
	String choice = "";

	while (!exCode) {
	    System.out.println("\u001B[33m" + "\nSelect Field to Update\n" + "\u001B[0m");

	    System.out.println("\u001B[32m" + "1. Name \n" + "2. E-mail address\n" + "3. Password\n" + "\u001B[0m"
		    + "\u001B[31m" + "0. Return to User Menu" + "\u001B[0m");

	    choice = OperationFactory.getScannerInstance().next();

	    switch (choice) {
	    case "1":
		try {
		    updateName(username);
		} catch (UserException e) {
		    this.printMenuException(e);
		}
		break;

	    case "2":
		try {
		    updateEmail(username);
		} catch (UserException e) {
		    this.printMenuException(e);
		}
		break;

	    case "3":
		try {
		    updatePassword(username);
		} catch (UserException e) {
		    this.printMenuException(e);
		}
		break;

	    case "0":
		exCode = true;
		break;

	    default:
		System.out.println("Please Enter Valid Option\n");
	    }

	}
	System.out.println("Returning to User Menu");

	return true;
    }

    private boolean updateName(String username) throws UserException, AppException {
	System.out.println("\u001B[31m" + "First Name :\n" + "\u001B[0m");
	String firstName = this.getFirstName();

	System.out.println("\u001B[31m" + "Last Name :\n" + "\u001B[0m");
	String lastName = this.getLastName();

	UserManager.getInstance().updateUser(username, "first_name", firstName);
	UserManager.getInstance().updateUser(username, "last_name", lastName);

	System.out.println("You Name has been updated to : " + firstName + " " + lastName);

	return true;
    }

    private boolean updateEmail(String username) throws AppException, UserException {
	System.out.println("\u001B[31m" + "E-mail Address :\n" + "\u001B[0m");
	String email = this.getEmail();

	UserManager.getInstance().updateUser(username, "email", email);

	System.out.println("Your contact E-mail address has been Updated to : " + email);

	return true;

    }

    private boolean updatePassword(String username) throws AppException, UserException {
	System.out.println("\u001B[31m" + "Existing Password :\n" + "\u001B[0m");
	String oldPassword = this.getExistingPassword(username);

	System.out.println("\u001B[31m" + "Enter New Password :\n" + "\u001B[0m" + "\u001B[33m"
		+ "[Should be of at least 8 characters, contain only letters and digits and "
		+ "must contain at least 2 digits]" + "\u001B[0m");
	String newPassword = this.getPassword();

	if (this.arePasswordsMatching(oldPassword, newPassword)) {
	    System.out.println("\u001B[31m" + "New Password is the same as Current password." + "\u001B[0m");
	    return false;
	}

	System.out.println("\u001B[31m" + "Enter New Password Again :\n" + "\u001B[0m");
	String newConfirmedPassword = this.getConfirmedPassword(newPassword);

	UserManager.getInstance().updateUser(username, "user_password", newConfirmedPassword);

	System.out.println("\u001B[32m" + "Your password has been updated. Hereafter, you must log-in using your new "
		+ "password\n" + "\u001B[0m");

	return true;
    }

    private boolean postClassified(String username) throws AppException, UserException {

	// Print message to enter Classified Details
	System.out.println("\u001B[36m" + "\nPlease Enter Classified Details Below One by One" + "\u001B[0m");

	// Get Classified Headline
	System.out.println("\u001B[31m" + "\nEnter Classfied Headline:" + "\u001B[0m");
	System.out.println("\u001B[33m" + "[Headline Should not exceed 100 Characters]\n" + "\u001B[0m");
	String headline = this.getClassifiedHeadline();

	// Get Classified Product Name
	System.out.println("\u001B[31m" + "\nEnter Classfied Product Name:" + "\u001B[0m");
	System.out.println("\u001B[33m" + "[Product Name Should not exceed 50 Characters]\n" + "\u001B[0m");
	String productName = this.getClassifiedProductName();

	// Get Classified Brand
	System.out.println("\u001B[31m" + "\nEnter Classfied Brand:" + "\u001B[0m");
	System.out.println("\u001B[33m" + "[Brand Name Should not exceed 25 Characters]\n" + "\u001B[0m");
	String brand = this.getClassifiedBrand();

	// Get Classified Condition
	System.out.println("\u001B[31m" + "\nChoose Condition:" + "\u001B[0m");
	String productCondition = this.getClassifiedCondition();

	// Get Classified Description
	System.out.println("\u001B[31m" + "\nEnter Classfied Description:" + "\u001B[0m");
	System.out.println("\u001B[33m" + "[Description Should not exceed 500 Characters]\n" + "\u001B[0m");
	String classifiedDescription = this.getClassifiedDescription();

	// Get Classified Price
	System.out.println("\u001B[31m" + "\nEnter Classfied Price:" + "\u001B[0m");
	double price = this.getClassifiedPrice();

	// Get Classified Image URL
	System.out.println("\u001B[31m" + "\nEnter Classfied Image URL:" + "\u001B[0m");
	String imageurl = this.getClassifiedImageurl();

	// Set Classified Seller 
	String seller = username;

	// Get Classified Category
	System.out.println("\u001B[31m" + "\nChoose Classfied Category by ID:\n" + "\u001B[0m");
	System.out.println("\u001B[36m" + "Available Categories:" + "\u001B[0m");
	ClassifiedCategoryManager.getInstance().viewAllCategories();

	System.out.println("\n\u001B[32mChoose a Classfied Category by Entering ID Below\u001B[0m");
	int categoryId = this.getCategoryId();

	if (!ClassifiedCategoryManager.getInstance().isValidCategory(categoryId)) {
	    System.out.println("\u001B[31m" + "Invalid ID Selected. Returning to previous menu" + "\u001B[0m");
	    return false;
	}

	// Create a new Classified object
	Classified newClassified = InfoFactory.getInstance().getClassifiedInstance(headline, productName, brand,
		productCondition, classifiedDescription, price, imageurl, seller, categoryId);

	// Call method to add Classified to the database
	ClassifiedManager.getInstance().addClassified(newClassified);

	// Print success message
	System.out.println("\u001B[32m" + "\nClassifed Added Successfully with Below Details :" + "\u001B[0m");
	ClassifiedManager.getInstance().retrieveClassified(newClassified.getClassifiedId());

	return true;
    }

    private boolean browseClassifieds(String username) throws AppException {
	boolean exCode = false;
	String choice = "";

	while (!exCode) {
	    System.out.println("\u001B[33m" + "\nChoose an Option\n" + "\u001B[0m");

	    System.out.println("\u001B[32m" + "1. View Classifieds Posted By You \n"
		    + "2. Browse Classifieds Posted By Other Users \n" + "\u001B[0m" + "\u001B[31m"
		    + "0. Return to User Menu" + "\u001B[0m");

	    choice = OperationFactory.getScannerInstance().next();

	    switch (choice) {
	    case "1":

		browseClassifiedsByUser(username);

		break;

	    case "2":

		browseClassifiedsByOthers(username);

		break;

	    case "0":
		exCode = true;
		break;

	    default:
		System.out.println("Please Enter Valid Option\n");
	    }

	}
	System.out.println("Returning to previous Menu");

	return true;
    }

    private boolean browseClassifiedsByUser(String username) throws AppException {
	System.out.println("\nView all Classifieds by you\n");
	ClassifiedManager.getInstance().retrieveAllClassifiedByUser(username);
	return true;
    }

    private boolean browseClassifiedsByOthers(String username) throws AppException {

	System.out.println("\nView all Classifieds by Other users\n");
	ClassifiedManager.getInstance().retrieveAllClassifiedForUser(username);

	boolean exCode = false;
	String choice = "";

	while (!exCode) {
	    System.out.println("\nFilter Option\n");

	    System.out.println("1. Price Low to High \n" + "2. Price High to Low\n" + "3. Browse Classifed by Seller\n"
		    + "4. Browse Classifed by Category\n" + "0. Return to User Menu");

	    choice = OperationFactory.getScannerInstance().next();

	    switch (choice) {
	    case "1":
		try {
		    priceLowToHigh(username);
		} catch (UserException e) {
		    this.printMenuException(e);
		}
		break;
	    case "2":
		try {
		    priceHighToLow(username);
		} catch (UserException e) {
		    this.printMenuException(e);
		}
		break;

	    case "3":
		try {
		    browseBySeller(username);
		} catch (UserException e) {
		    this.printMenuException(e);
		}
		break;

	    case "4":
		try {
		    browseByCategory(username);
		} catch (UserException e) {
		    this.printMenuException(e);
		}
		break;

	    case "0":
		exCode = true;
		break;

	    default:
		System.out.println("Please Enter Valid Option\n");
	    }

	}
	System.out.println("Returning to User Menu");

	return true;
    }

    private boolean priceHighToLow(String username) throws AppException, UserException {

	System.out.println("\nView all Classifieds by Price Low to High \n");
	ClassifiedManager.getInstance().retrieveClassifiedPriceHighToLow(username);

	buyClassified(username);

	return true;
    }

    private boolean priceLowToHigh(String username) throws AppException, UserException {

	System.out.println("\nView all Classifieds by Price High to Low \n");
	ClassifiedManager.getInstance().retrieveClassifiedPriceLowToHigh(username);

	buyClassified(username);

	return true;
    }

    private boolean browseBySeller(String username) throws AppException, UserException {

	System.out.println("List of Sellers");
	ClassifiedManager.getInstance().retreiveSeller(username);

	System.out.println("\nEnter Seller Name Below");
	String seller = this.getSellerName();

	if (!ClassifiedManager.getInstance().isValidSellerForBuyer(username, seller)) {

	    System.out.println("Seller Not Found!\n");
	    return false;
	}

	System.out.println("\nView all Classifieds by The Seller \n");
	ClassifiedManager.getInstance().retrieveClassifiedBySeller(seller);

	buyClassified(username);
	return true;
    }

    private boolean browseByCategory(String username) throws AppException, UserException {
	System.out.println("\u001B[31m" + "\nChoose Classfied Category by ID:\n" + "\u001B[0m");
	System.out.println("\u001B[36m" + "Available Categories:" + "\u001B[0m");
	ClassifiedCategoryManager.getInstance().viewAllCategories();

	System.out.println("\n\u001B[32mChoose a Classfied Category by Entering ID Below\u001B[0m");
	int id = this.getCategoryId();

	if (!ClassifiedCategoryManager.getInstance().isValidCategory(id)) {
	    System.out.println("\u001B[31m" + "Invalid ID Selected. Returning to previous menu" + "\u001B[0m");
	    return false;
	}

	String category = ClassifiedCategoryManager.getInstance().getCategoryName(id);

	System.out.println("\n View Classifieds by Selected Category \n");
	ClassifiedManager.getInstance().retrieveClassifiedByCategory(category);

	buyClassified(username);
	return true;

    }

    private boolean buyClassified(String username) throws UserException, AppException {

	System.out.println("\nEnter Classified ID for Product Details");
	int id = this.getClassifiedId();

	if (!ClassifiedManager.getInstance().isValidClassifiedIdForBuyer(username, id)) {
	    System.out.println("Invalid ID. Returning to previous Mennu");
	    return false;
	}

	System.out.println("\nDetails Below");
	ClassifiedManager.getInstance().getClassifiedDetails(username, id);

	boolean exCode = false;
	String choice = "";

	while (!exCode) {
	    System.out.println("\nSelect an Option\n");

	    System.out.println("1. Buy Classified\n" + "2. Contact Seller\n" + "0. Return to Previous Menu");

	    choice = OperationFactory.getScannerInstance().next();

	    switch (choice) {
	    case "1":
		performBuy(username, id);

		break;

	    case "2":
		composeMessage(username, id);

		break;

	    case "0":

		exCode = true;
		break;

	    default:
		System.out.println("Please Enter Valid Option\n");
	    }

	}

	return true;
    }

    private boolean performBuy(String buyer, int classifiedId) throws UserException, AppException {

	int buyerId = UserManager.getInstance().getUserId(buyer);
	System.out.println("\nAvailable Payment Methods\n");
	PaymentManager.getInstance().retrieveAllPaymentMethodForUser(buyerId);
	System.out.println("\nPlease Enter Payment ID");
	int paymentId = this.getPaymentId();
	if (!PaymentManager.getInstance().isValidPaymentMethod(paymentId, buyerId)) {
	    System.out.println("\nInvalid Payment ID. Please Try Again\n");
	    return false;
	}
	int amount = ClassifiedManager.getInstance().getPrice(classifiedId);
	String time = this.getDateTimeString();

	Transaction newTransaction = InfoFactory.getInstance().getTransactionInstance(buyerId, classifiedId, amount,
		paymentId, time);

	TransactionManager.getInstance().createTransaction(newTransaction);

	ClassifiedManager.getInstance().updateClassified(classifiedId, "classified_status", "sold");

	System.out.println("Processing Payment . . .");
	System.out.println("Purchase Sucessful. Please check your transaction tab for Details\n");

	return true;
    }

    private boolean connectWithUsers(String username) throws AppException {

	boolean exCode = false;
	String choice = "";

	while (!exCode) {
	    System.out.println("\nSelect an Option\n");

	    System.out.println("1. Connect with Other Users \n" + "2. View Inbox \n" + "3. View Sent Messages \n"
		    + "0. Return to User Menu");

	    choice = OperationFactory.getScannerInstance().next();

	    switch (choice) {
	    case "1":
		try {
		    browseBySeller(username);
		} catch (UserException e) {
		    this.printMenuException(e);
		}
		break;
	    case "2":
		viewInbox(username);
		break;
	    case "3":
		try {
		    viewSentMessage(username);
		} catch (UserException e) {
		    this.printMenuException(e);
		}
		break;

	    case "0":
		exCode = true;
		break;

	    default:
		System.out.println("Please Enter Valid Option\n");
	    }

	}
	System.out.println("Returning to previous Menu");

	return true;
    }

    private boolean viewSentMessage(String username) throws AppException, UserException {
	if (CommunicationManager.getInstance().retrieveSentMessages(username)) {
	    System.out.println("View Sent Messages\n");
	    CommunicationManager.getInstance().retrieveSentMessages(username);
	} else {
	    System.out.println("Returning to previous menu");
	    return false;
	}

	System.out.println("Enter The Message ID you want to read");
	int id = this.getMessageId();

	if (!CommunicationManager.getInstance().isValidMessage(id)) {
	    System.out.println("Invalid Message ID");
	    return false;
	}

	System.out.println("Message Body :\n");
	CommunicationManager.getInstance().retrieveMessageBody(id);

	return true;
    }

    private boolean viewInbox(String username) throws AppException {

	boolean exCode = false;
	String choice = "";

	while (!exCode) {
	    System.out.println("\nChoose an Option :\n");

	    System.out.println(
		    "1. View unread Messages \n" + "2. View Messages already read \n" + "0. Return to previous Menu");

	    choice = OperationFactory.getScannerInstance().next();

	    switch (choice) {
	    case "1":
		try {
		    viewUnreadMessages(username);
		} catch (UserException e) {
		    this.printMenuException(e);
		}
		break;

	    case "2":
		try {
		    viewAlreadyReadMessages(username);
		} catch (UserException e) {
		    this.printMenuException(e);
		}
		break;

	    case "0":
		exCode = true;
		break;

	    default:
		System.out.println("Please Enter Valid Option\n");
	    }

	}
	System.out.println("Returning to previous Menu");

	return true;
    }

    private boolean viewAlreadyReadMessages(String username) throws AppException, UserException {

	if (CommunicationManager.getInstance().isValidReadMessagesForUser(username)) {
	    System.out.println("List of messages already read");
	    CommunicationManager.getInstance().retrieveReadMessagesForUser(username);
	} else {
	    System.out.println("Returning to previous menu");
	    return false;
	}

	System.out.println("Enter The Message ID you want to read");
	int id = this.getMessageId();

	if (!CommunicationManager.getInstance().isValidMessage(id)) {
	    System.out.println("Invalid Message ID");
	    return false;
	}
	sendReply(username, id);
	return true;
    }

    private boolean viewUnreadMessages(String username) throws AppException, UserException {

	if (CommunicationManager.getInstance().isValidUneadMessagesForUser(username)) {
	    System.out.println("List of unread messages");
	    CommunicationManager.getInstance().retrieveUneadMessagesForUser(username);
	} else {
	    System.out.println("Returning to previous menu");
	    return false;
	}

	System.out.println("Enter The Message ID you want to read");
	int id = this.getMessageId();

	if (!CommunicationManager.getInstance().isValidMessage(id)) {
	    System.out.println("Invalid Message ID");
	    return false;
	}
	sendReply(username, id);
	return true;
    }

    private boolean sendReply(String sender, int messageId) throws AppException {

	System.out.println("Message Body :\n");
	CommunicationManager.getInstance().retrieveMessageBody(messageId);

	boolean exCode = false;
	String choice = "";

	while (!exCode) {
	    System.out.println("Choose an Option :\n");
	    System.out.println("1. Reply to Message  \n" + "0. Return to previous Menu");

	    choice = OperationFactory.getScannerInstance().next();

	    switch (choice) {
	    case "1":
		try {
		    replyToMessage(sender, messageId);
		} catch (UserException e) {
		    this.printMenuException(e);
		}
		break;

	    case "0":
		exCode = true;
		break;

	    default:
		System.out.println("Please Enter Valid Option\n");
	    }

	}
	System.out.println("Returning to previous Menu");
	return true;
    }

    private boolean replyToMessage(String sender, int messageId) throws UserException, AppException {

	String status = CommunicationManager.getInstance().getCommunicationStatus(messageId);

	if (status.equals("unread")) {
	    status = "read";
	    CommunicationManager.getInstance().updateMessageStatus(messageId, "status", status);
	}

	String receiver = CommunicationManager.getInstance().getSenderName(messageId);
	String time = this.getDateTimeString();
	System.out.println("\nEnter Your reply message");
	String reply = this.getMessage();
	int classifiedId = CommunicationManager.getInstance().getClassifiedId(messageId);
	String type = CommunicationManager.getInstance().getSenderType(messageId);

	if (type.equals("buyer")) {
	    type = "seller";
	} else {
	    type = "buyer";
	}

	Communication newComm = InfoFactory.getInstance().getCommunicationInstance(classifiedId, sender, receiver,
		reply, time, type);
	CommunicationManager.getInstance().createCommunication(newComm);

	System.out.println("Reply sent Successfully");

	return true;
    }

    private void composeMessage(String sender, int classifiedId) throws UserException, AppException {

	String receiver = ClassifiedManager.getInstance().getSellerName(classifiedId);
	System.out.println("Please Enter Your Message\n");
	String message = this.getMessage();
	String time = this.getDateTimeString();
	String senderType = "buyer";

	Communication newCommunication = InfoFactory.getInstance().getCommunicationInstance(classifiedId, sender,
		receiver, message, time, senderType);
	CommunicationManager.getInstance().createCommunication(newCommunication);

	System.out.println("Your Message sent successfully.");

    }

}
