package Functionality;

import exceptionHandling.AppException;

/*
 * Home page or outer layer 
 * 
 * Menu:-
 * 0. Exit
 * 1. Admin
 * 2. User
 * 
 */

public class AppDriver {
    public void initiate() {
	boolean exitCode = false;

	while (!exitCode) {
	    System.out.println("\033[1m\u001B[35m\u001B[43m" + "   Welcome  to  Amazon  Internals  Classified  App   "
		    + "\u001B[0m");
	    System.out.println("\n\u001B[33m" + "Please Choose Your Category" + "\u001B[0m");
	    System.out.println("\n\u001B[32m1. Administrator \n2. User\u001B[0m \n" + "\u001B[31m0. Exit\n\u001B[0m");
	    String choice = OperationFactory.getScannerInstance().next();
	    switch (choice) {
	    case "1":
		System.out.println("\u001B[36m" + "Admin Login\n" + "\u001B[0m");
		try {
		    OperationFactory.getAdminLoginInstance().showMenu();
		} catch (AppException e) {
		    System.out.println(e.getMessage());
		    e.printStackTrace();
		}
		break;
	    case "2":
		try {
		    OperationFactory.getUserLoginInstance().showMenu();
		} catch (AppException e) {
		    System.out.println(e.getMessage());
		    e.printStackTrace();
		}
		break;
	    case "0":
		exitCode = true;
		break;
	    default:
		System.out.println("Please enter a valid operation");
	    }

	}

	System.out.println("\n\u001B[36m" + "Thank you for using Amazon Internals Classified App.\n\n" + "\u001B[0m");

    }
}