package Functionality;

import exceptionHandling.AppException;
import exceptionHandling.UserException;

import java.time.LocalDateTime;
import java.util.InputMismatchException;
import java.util.Scanner;

import Administration.UserExecutor;
import database.PasswordValidation;

/**
 * The class BaseOperation is a parent class for multiple Operation Classes in
 * operations package. It works as a gateway between the operations
 * package/Upper Layer/User and the managers package/Middle Layer. It provides
 * an upper-layer exception enclosure around common functions being used by the
 * child classes. The child classes interact with the manager layer and user via
 * these functions, while any exceptions occurring due to user behaviour are
 * thrown.
 **/

public class BaseOperation {

    private final static int MAX_PASSWORD_CONFIRM_TRIES = 3;
    private final static int MAX_PASSWORD_TRIES = 3;
    private final static int MAX_EXISTING_PASSWORD_TRIES = 3;

    protected String getDate() throws UserException {
	Scanner sc = OperationFactory.getScannerInstance();

	String date;

	try {
	    date = sc.next();
	} catch (InputMismatchException e) {
	    throw new UserException("Entered date is Invalid");
	}

	if (!PasswordValidation.isValidDate(date)) {
	    throw new UserException("Please Enter Valid Date with proper Format");
	}

	return date;
    }

    protected String getUsername() throws UserException {
	Scanner sc = OperationFactory.getScannerInstance();

	String username;

	try {
	    username = sc.next();
	} catch (InputMismatchException e) {
	    throw new UserException("Entered username is Invalid");
	}

	if (!PasswordValidation.isValidUsername(username)) {
	    throw new UserException(
		    "userame should be atleast 5 character long and should be less than 30, contains only letter and number");
	}
	return username;
    }

    protected String getSellerName() throws UserException {
	Scanner sc = OperationFactory.getScannerInstance();

	String username;

	try {
	    username = sc.next();
	} catch (InputMismatchException e) {
	    throw new UserException("Entered Seller Name is Invalid");
	}

	if (!PasswordValidation.isValidUsername(username)) {
	    throw new UserException("Seller Name Not Matching. Please try again.");
	}
	return username;
    }

    protected String getPaymentMethod() throws UserException {
	String paymentMethod = "";
	boolean isValidChoice = false;

	while (!isValidChoice) {

	    System.out.println("\u001B[36m" + "Choose an Option Below : " + "\u001B[0m");
	    System.out.println("\u001B[32m" + "\n1. Credit Card  \n" + "2. Debit Card \n" + "\u001B[0m" + "\u001B[33m"
		    + "3. PayPal \n" + "\u001B[0m");
	    String choice = OperationFactory.getScannerInstance().next();
	    switch (choice) {
	    case "1":
		paymentMethod = "Credit Card";
		isValidChoice = true;
		break;
	    case "2":
		paymentMethod = "Debit Card";
		isValidChoice = true;
		break;
	    case "3":
		paymentMethod = "PayPal";
		isValidChoice = true;
		break;
	    default:
		System.out.println("Please enter a valid operation");
	    }
	}

	if (PasswordValidation.isBlank(paymentMethod)) {
	    throw new UserException("Blank input Detected");
	}

	System.out.println("\u001B[32m" + "You have selected Payment Method as : " + "\u001B[0m" + paymentMethod);
	return paymentMethod;
    }

    protected String getCardDetails() throws UserException {

	Scanner sc = OperationFactory.getScannerInstance();

	String details;

	try {

	    details = sc.next();
	} catch (InputMismatchException e) {
	    throw new UserException("\nInvalid Number");
	}

	if (!PasswordValidation.isNumeric(details)) {
	    throw new UserException("\nshould be a numeric value.");
	}

	if (!PasswordValidation.isValidCardLength(details)) {
	    throw new UserException("\nShould be a 16 Digit Number.");
	}

	return details;

    }

    protected String getFirstName() throws UserException {
	Scanner sc = OperationFactory.getScannerInstance();

	String firstName;

	try {
	    firstName = sc.next();
	} catch (InputMismatchException e) {
	    throw new UserException("Entered Name is Invalid");
	}

	if (!PasswordValidation.isValidNameLength(firstName)) {
	    throw new UserException("First Name should be below 30 characters ");
	}

	if (!PasswordValidation.isAlphabetic(firstName)) {
	    throw new UserException("First Name can only contain alphabets");
	}
	return firstName;
    }

    protected String getLastName() throws UserException {
	Scanner sc = OperationFactory.getScannerInstance();

	String lastName;

	try {
	    lastName = sc.next();
	} catch (InputMismatchException e) {
	    throw new UserException("Entered Name is Invalid");
	}

	if (!PasswordValidation.isValidNameLength(lastName)) {
	    throw new UserException("Last Name not Valid. Should be below - 30 characters ");
	}

	if (!PasswordValidation.isAlphabetic(lastName)) {
	    throw new UserException("Last Name can only contain alphabets");
	}

	return lastName;
    }

    protected String getEmail() throws UserException {
	Scanner sc = OperationFactory.getScannerInstance();

	String emailAddress;

	try {
	    emailAddress = sc.next();
	} catch (InputMismatchException e) {
	    throw new UserException("Entered e-mail address is Invalid ");
	}

	if (!PasswordValidation.isValidEmail(emailAddress)) {
	    throw new UserException(
		    "Email Address not Valid.\n Format should be : abcd@amazon.com," + "xyz@gmail.com,etc. ");
	}
	return emailAddress;
    }

    protected String getPassword() throws UserException {
	Scanner sc = OperationFactory.getScannerInstance();

	String password;
	int passwordTries = 1;

	try {
	    password = sc.next();
	} catch (InputMismatchException e) {
	    throw new UserException("Entered Password is Invalid ");
	}

	while (passwordTries < MAX_PASSWORD_TRIES) {
	    if (!PasswordValidation.isValidPassword(password)) {
		++passwordTries;
		System.out.println("Please Enter a Valid password [Only 3 tries Allowed]: \n"
			+ " 1. A password must have at least eight characters.\n"
			+ " 2. A password consists of only letters and digits.\n"
			+ " 3. A password must contain at least two digits \n");
		try {
		    password = sc.next();
		} catch (InputMismatchException e) {
		    throw new UserException("Entered Password is Invalid ");
		}
	    } else {
		return password;
	    }
	}
	if (!PasswordValidation.isValidPassword(password)) {
	    throw new UserException("Password tries Exhausted");
	}
	return password;
    }

    // PARAMs
    protected String getConfirmedPassword(String password) throws UserException {
	Scanner sc = OperationFactory.getScannerInstance();

	String confirmedPassword;
	int passwordConfirmTries = 1;

	try {
	    confirmedPassword = sc.next();
	} catch (InputMismatchException e) {
	    throw new UserException("Entered Password is Invalid ");
	}

	while (passwordConfirmTries <= MAX_PASSWORD_CONFIRM_TRIES) {
	    if (!PasswordValidation.arePasswordsMatching(password, confirmedPassword)) {
		++passwordConfirmTries;
		System.out.println("Please Enter a password which matches previous password value "
			+ "[Only 3 tries Allowed]: \n");
		try {
		    confirmedPassword = sc.next();
		} catch (InputMismatchException e) {
		    throw new UserException("Entered Password is Invalid ");
		}
	    } else {
		return confirmedPassword;
	    }
	}
	if (!PasswordValidation.arePasswordsMatching(password, confirmedPassword)) {
	    throw new UserException("Both Passwords do not match. Password tries Exhausted");
	}
	return confirmedPassword;
    }

    protected String getExistingPassword(String username) throws UserException, AppException {
	Scanner sc = OperationFactory.getScannerInstance();

	String existingPassword;
	int passwordEntryCount = 1;

	try {
	    existingPassword = sc.next();
	} catch (InputMismatchException e) {
	    throw new UserException("Entered Password is Invalid ");
	}

	while (passwordEntryCount <= MAX_EXISTING_PASSWORD_TRIES) {
	    if (!UserExecutor.getInstance().isValidUserPassword(username, existingPassword)) {
		++passwordEntryCount;
		System.out.println("Please enter value which matches current password " + "[Only 3 tries Allowed]: \n");
		try {
		    existingPassword = sc.next();
		} catch (InputMismatchException e) {
		    throw new UserException("Entered Password is invalid.");
		}
	    } else {
		return existingPassword;
	    }
	}
	if (!UserExecutor.getInstance().isValidUserPassword(username, existingPassword)) {
	    throw new UserException("Entered Password does not match existing value." + "Password tries Exhausted");
	}
	return existingPassword;
    }

    protected int getUserId() throws UserException {
	Scanner sc = OperationFactory.getScannerInstance();

	int userId;

	try {

	    userId = sc.nextInt();
	} catch (InputMismatchException e) {
	    throw new UserException("\n Please enter correct Employee ID. " + "\n It is a 9 digit number"
		    + "\n You check your Phonetool Or, contact your manager to find further " + "information\n");
	}

	if (!PasswordValidation.isPositive(userId)) {
	    throw new UserException("\n Employee ID cannot be a negative number.");
	}

	if (!PasswordValidation.isValidUserIdLength(userId)) {
	    throw new UserException("The entered value is not a valid Employee id" + "\nIt is a 9 digit number"
		    + "\nYou check your Phonetool Or, Contact your manager to find further " + "information\n");

	}

	return userId;
    }

    protected boolean arePasswordsMatching(String oldPassword, String newPassword) {
	return PasswordValidation.arePasswordsMatching(oldPassword, newPassword);
    }

    protected String getAdminId() throws UserException {
	Scanner sc = OperationFactory.getScannerInstance();

	String adminId;

	try {
	    adminId = sc.next();
	} catch (InputMismatchException e) {
	    throw new UserException(" Invalid Value Entered.");
	}
	return adminId;
    }

    protected String getAdminPassword() throws UserException {
	Scanner sc = OperationFactory.getScannerInstance();

	String adminPassword;

	try {
	    adminPassword = sc.next();
	} catch (InputMismatchException e) {
	    throw new UserException(" Invalid Password Entered.");
	}
	return adminPassword;
    }

    protected int getClassifiedId() throws UserException {
	Scanner sc = OperationFactory.getScannerInstance();

	int classifiedId;

	try {
	    classifiedId = sc.nextInt();
	} catch (InputMismatchException e) {
	    throw new UserException("\n Please enter valid ID, is an integer number.");
	}

	if (!PasswordValidation.isPositive(classifiedId)) {
	    throw new UserException("\nID cannot be negative");
	}

	return classifiedId;
    }

    protected int getMessageId() throws UserException {
	Scanner sc = OperationFactory.getScannerInstance();

	int id;

	try {
	    id = sc.nextInt();
	} catch (InputMismatchException e) {
	    throw new UserException("\n Please enter valid ID. Message ID is an integer number.");
	}

	if (!PasswordValidation.isPositive(id)) {
	    throw new UserException("\nID cannot be negative");
	}

	return id;
    }

    protected int getPaymentId() throws UserException {
	Scanner sc = OperationFactory.getScannerInstance();

	int id;

	try {
	    id = sc.nextInt();
	} catch (InputMismatchException e) {
	    throw new UserException("\n Please enter valid ID, is an integer number.");
	}

	if (!PasswordValidation.isPositive(id)) {
	    throw new UserException("\nID cannot be negative");
	}

	return id;
    }

    protected String getDateTimeString() throws UserException {
	    LocalDateTime dateTime = LocalDateTime.now();
	    String date = String.format("%04d-%02d-%02d", dateTime.getYear(), dateTime.getMonthValue(), dateTime.getDayOfMonth());
	    String time = String.format("%02d:%02d:%02d", dateTime.getHour(), dateTime.getMinute(), dateTime.getSecond());
	    return date + " " + time;
	}

    protected void printMenuException(UserException e) {
	System.out.println("Returning to previous menu as the below issue has occurred.\n");
	System.out.println(e.getMessage());
    }

    protected String getClassifiedHeadline() throws UserException {
	Scanner sc = OperationFactory.getScannerInstance();

	String headline;

	try {
	    headline = sc.next();
	} catch (InputMismatchException e) {
	    throw new UserException("Entered Comment is Invalid");
	}

	if (PasswordValidation.isBlank(headline)) {
	    throw new UserException("Blank input Detected");
	}

	if (!PasswordValidation.isValidClassifiedHeadline(headline)) {
	    throw new UserException("Please enter headline within a character limit of 100 ");
	}
	return headline;
    }

    protected String getClassifiedProductName() throws UserException {
	Scanner sc = OperationFactory.getScannerInstance();

	String productName;

	try {
	    productName = sc.next();
	} catch (InputMismatchException e) {
	    throw new UserException("Entered Comment is Invalid");
	}

	if (PasswordValidation.isBlank(productName)) {
	    throw new UserException("Blank input Detected");
	}

	if (!PasswordValidation.isValidClassifiedProductName(productName)) {
	    throw new UserException("Please enter product name within a character limit of 50 ");
	}
	return productName;
    }

    protected String getClassifiedBrand() throws UserException {
	Scanner sc = OperationFactory.getScannerInstance();

	String brand;

	try {
	    brand = sc.next();
	} catch (InputMismatchException e) {
	    throw new UserException("Entered Comment is Invalid");
	}

	if (PasswordValidation.isBlank(brand)) {
	    throw new UserException("Blank input Detected");
	}

	if (!PasswordValidation.isValidClassifiedBrand(brand)) {
	    throw new UserException("Please enter brand name within a character limit of 25 ");
	}
	return brand;
    }

    protected String getClassifiedCondition() throws UserException {

	String condition = "";
	boolean isValidChoice = false;

	while (!isValidChoice) {

	    System.out.println("\u001B[36m" + "Choose an Option Below : " + "\u001B[0m");
	    System.out.println("\u001B[32m" + "\n1. Brand New  \n" + "2. Lightly Used \n" + "\u001B[0m" + "\u001B[33m"
		    + "3. Moderately Used \n" + "4. Heavily Used \n" + "\u001B[0m" + "\u001B[31m"
		    + "5. Damaged/Dented \n" + "6. Not Working \n" + "\u001B[0m");
	    String choice = OperationFactory.getScannerInstance().next();
	    switch (choice) {
	    case "1":
		condition = "Brand New";
		isValidChoice = true;
		break;
	    case "2":
		condition = "Lightly Used";
		isValidChoice = true;
		break;
	    case "3":
		condition = "Moderately Used";
		isValidChoice = true;
		break;
	    case "4":
		condition = "Heavily Used";
		isValidChoice = true;
		break;
	    case "5":
		condition = "Damaged or Dented";
		isValidChoice = true;
		break;
	    case "6":
		condition = "Not Working";
		isValidChoice = true;
		break;
	    default:
		System.out.println("Please enter a valid operation");
	    }
	}

	if (PasswordValidation.isBlank(condition)) {
	    throw new UserException("Blank input Detected");
	}

	System.out.println("\u001B[32m" + "You have selected condition as : " + "\u001B[0m" + condition);
	return condition;
    }

    protected String getClassifiedDescription() throws UserException {
	Scanner sc = OperationFactory.getScannerInstance();

	String description;

	try {
	    description = sc.next();
	} catch (InputMismatchException e) {
	    throw new UserException("Entered Comment is Invalid");
	}

	if (PasswordValidation.isBlank(description)) {
	    throw new UserException("Blank input Detected");
	}

	if (!PasswordValidation.isValidClassifiedDescription(description)) {
	    throw new UserException("Please enter description within a character limit of 500 ");
	}
	return description;
    }

    protected String getMessage() throws UserException {
	Scanner sc = OperationFactory.getScannerInstance();

	String description;

	try {
	    description = sc.next();
	} catch (InputMismatchException e) {
	    throw new UserException("Entered Comment is Invalid");
	}

	if (PasswordValidation.isBlank(description)) {
	    throw new UserException("Blank input Detected");
	}

	if (!PasswordValidation.isValidMessage(description)) {
	    throw new UserException("Please enter message within a character limit of 300 ");
	}
	return description;
    }

    protected double getClassifiedPrice() throws UserException {
	Scanner sc = OperationFactory.getScannerInstance();

	double price;

	try {
	    price = sc.nextDouble();
	} catch (InputMismatchException e) {
	    throw new UserException("Invalid Input Detected. Should be Numeric value");
	}

	if (PasswordValidation.isBlank(price)) {
	    throw new UserException("Blank input Detected");
	}

	return price;
    }

    protected String getClassifiedImageurl() throws UserException {
	Scanner sc = OperationFactory.getScannerInstance();

	String imageurl;

	try {
	    imageurl = sc.next();
	} catch (InputMismatchException e) {
	    throw new UserException("Entered Comment is Invalid");
	}

	if (!PasswordValidation.isValidClassifiedUrl(imageurl)) {
	    throw new UserException("Link character should not exceed 100. Put short link");
	}

	if (PasswordValidation.isBlank(imageurl)) {
	    throw new UserException("Blank input Detected");
	}

	return imageurl;
    }

    protected String getCategoryName() throws UserException {
	Scanner sc = OperationFactory.getScannerInstance();

	String categoryname;

	try {
	    categoryname = sc.next();
	} catch (InputMismatchException e) {
	    throw new UserException("Entered Comment is Invalid");
	}
	if (!PasswordValidation.isAlphabetic(categoryname)) {
	    throw new UserException("should be alphabetic");

	}

	if (PasswordValidation.isBlank(categoryname)) {
	    throw new UserException("Blank input Detected");
	}

	return categoryname;
    }

    protected String getCategoryDescription() throws UserException {
	Scanner sc = OperationFactory.getScannerInstance();

	String description;

	try {
	    description = sc.next();
	} catch (InputMismatchException e) {
	    throw new UserException("Invalid Input");
	}

	if (PasswordValidation.isBlank(description)) {
	    throw new UserException("Blank input Detected");
	}

	return description;
    }

    protected int getCategoryId() throws UserException {

	Scanner sc = OperationFactory.getScannerInstance();

	int id;

	try {
	    id = sc.nextInt();
	} catch (InputMismatchException e) {
	    throw new UserException("ID should be an Integer Value");
	}

	if (PasswordValidation.isBlank(id)) {
	    throw new UserException("Blank input Detected");
	}

	return id;
    }

}
