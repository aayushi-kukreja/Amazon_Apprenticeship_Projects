
/*
The class AdminOperation implements the functionality of an administrator of the system. 
The administrator has access to various operations such as approving/rejecting classified, 
activating/deactivating users, adding/removing classified, managing classified categories, 
and generating reports.
*/

package Functionality;

import Administration.ClassifiedListExecutor;
import Administration.ClassifiedExecutor;
import Administration.UserExecutor;
import exceptionHandling.AppException;
import exceptionHandling.UserException;
import resources.Classified;
import resources.ClassifiedList;
import resources.ShopInformation;

public class AdminFunction extends BaseOperation {

    // Show the main menu for administrator operations
    public boolean showMenu() throws AppException {
	boolean exitCode = false;

	// Loop through the menu options until the exitCode is set to true
	while (!exitCode) {
	    // Print the menu header in yellow
	    System.out.println("\n\u001B[33mWelcome to Admin's Operation Menu" + "\nChoose an Option Below :\u001B[0m");

	    // Print the menu options
	    System.out
		    .println("\n\u001B[32m1. Approve or Reject a Classified \n" + "2. Activate or Deactivate an User \n"
			    + "3. Add or Remove a Classified \n" + "4. Manage Classified Category \n"
			    + "\u001B[31m0. Log Out \u001B[0m");

	    // Read the user's choice
	    String choice = OperationFactory.getScannerInstance().next();

	    // Perform the action based on the user's choice
	    switch (choice) {
	    case "1":
		try {
		    // Call the method to update classified status
		    updateClassifiedStatusMenu();
		} catch (UserException e) {
		    // Print the exception message
		    this.printMenuException(e);
		}
		break;
	    case "2":
		try {
		    // Call the method to update user status
		    updateUserStatusMenu();
		} catch (UserException e) {
		    // Print the exception message
		    this.printMenuException(e);
		}
		break;
	    case "3":
		try {
		    manageClassifiedAsAdminMenu();
		} catch (UserException e) {
		    // Print the exception message
		    this.printMenuException(e);
		}
		break;
	    case "4":
		// Call the method to manage classified categories
		manageClassifiedCategoryMenu();
		break;
	   
	    case "0":
		System.out.println("\n\u001B[32m" + "Logged Out Successfully\n" + "\u001B[0m");
		// Set exitCode to true to break out of the loop
		exitCode = true;
		break;
	    default:
		// Print a message if the choice is invalid
		System.out.println("Please enter a valid operation");
	    }
	}

	// Print a message indicating that the user has returned to the previous menu
	System.out.println("\u001B[36m" + "Returning to LOGIN Menu\n\n" + "\u001B[0m");

	return true;
    }

   



    // Show the menu for updating the status of a classified

    private boolean updateClassifiedStatusMenu() throws UserException, AppException {

	System.out.println("\n\u001B[33m" + "Welcome to Classified Status Update Menu" + "\u001B[0m");

	boolean exitCode = false;
	String choice = "";

	// Loop through until exitCode is true
	while (!exitCode) {
	    System.out.println("\n\u001B[33m" + "Welcome to Classified Status Update Menu" + "\u001B[0m");
	    System.out.println("\u001B[33m" + "Choose Option an Below :" + "\u001B[0m");
	    System.out.println("\u001B[32m" + "\n1. Approve" + "\u001B[0m" + "\u001B[31m"
		    + "\n2. Reject \n0. Back to Previous Menu " + "\u001B[0m");
	    choice = OperationFactory.getScannerInstance().next();

	    // Perform the chosen operation
	    switch (choice) {
	    case "1":
		try {
		    approveClassifed();
		} catch (UserException e) {
		    this.printMenuException(e);
		}
		break;
	    case "2":
		try {
		    rejectClassified();
		} catch (UserException e) {
		    this.printMenuException(e);
		}
		break;
	    case "0":
		System.out.println("\u001B[31m" + "You have chosen to exit\n" + "\u001B[0m");
		exitCode = true;
		break;
	    default:
		System.out.println("Please enter a valid operation");
	    }
	}
	System.out.println("\u001B[31m" + "Returning to Admin's Operation Menu" + "\u001B[0m");
	return true;
    }

    private boolean approveClassifed() throws AppException, UserException {
	// current status of the classified to be approved
	String currentStatus = "pending";
	// updated status after approval
	String updatedStatus = "approved";

	// Display the list of classifieds with pending status
	System.out.println("\u001B[36m" + "\nList of Classifieds" + "\u001B[0m\n");
	ClassifiedExecutor.getInstance().retrieveRequiredClassifiedsForAdmin(currentStatus);

	// Prompt the user to enter the ID of the classified ad to update
	System.out.println("\n\u001B[31m" + "Please Enter The ID You Want to Approve" + "\u001B[0m");
	int id = this.getClassifiedId();

	// Check if the entered ID is valid
	if (!ClassifiedExecutor.getInstance().isValidClassifiedId(id)) {
	    System.out.println("\u001B[31m" + "Invalid Classified ID. Returning to Classified Status Update Menu."
		    + "\u001B[0m\n");
	    return false;
	}

	// Check if the status of the classified ad is pending
	if (!ClassifiedExecutor.getInstance().isValidCurrentClassifiedStatus(id, currentStatus)) {
	    System.out.println("\u001B[31m" + "Status has not been updated because status is not " + currentStatus
		    + " for Classified ID : " + id + "\u001B[0m");
	    System.out.println("\u001B[31m" + "Returning to Status Update Menu.\n" + "\u001B[0m");
	    return false;
	}

	// Update the status of the classified ad to approved
	ClassifiedExecutor.getInstance().updateClassified(id, "classified_status", updatedStatus);

	// Display the success message
	System.out.println("\u001B[32m" + "Successfully Approved Classified!" + "\u001B[0m");

	return true;
    }

    private boolean rejectClassified() throws AppException, UserException {
	// current status of the classified to be rejected
	String currentStatus = "pending";
	// updated status after rejection
	String updatedStatus = "rejected";

	// display the list of classifieds with pending status
	System.out.println("\u001B[36m" + "\nList of Classifieds\n" + "\u001B[0m\n");
	ClassifiedExecutor.getInstance().retrieveRequiredClassifiedsForAdmin(currentStatus);

	// prompt user to enter the id of the classified to be rejected
	System.out.println("\n\u001B[31m" + "Please Enter The ID You Want to Reject" + "\u001B[0m");
	int id = this.getClassifiedId();

	// check if the id entered is valid or not
	if (!ClassifiedExecutor.getInstance().isValidClassifiedId(id)) {
	    System.out.println("\u001B[31m" + "Invalid Classified ID. Returning to Classified Status Update Menu."
		    + "\u001B[0m\n");
	    return false;
	}

	// check if the current status of the classified is pending
	if (!ClassifiedExecutor.getInstance().isValidCurrentClassifiedStatus(id, currentStatus)) {
	    System.out.println("\u001B[31m" + "Status has not been updated because status is not " + currentStatus
		    + " for Classified ID : " + id + "\u001B[0m");
	    System.out.println("\u001B[31m" + "Returning to Status Update Menu.\n" + "\u001B[0m");
	    return false;
	}

	// update the status of the classified to rejected
	ClassifiedExecutor.getInstance().updateClassified(id, "classified_status", updatedStatus);

	// display success message after updating the status
	System.out.println("\u001B[32m" + "Successfully Rejected Classified!" + "\u001B[0m");

	return true;
    }

    // Implement Option 2 : Activate/Deactivate user starts here.

    private boolean updateUserStatusMenu() throws UserException, AppException {

	// flag to exit the loop
	boolean exCode = false;
	String choice = "";

	// loop until exit code is not true
	while (!exCode) {

	    // print menu options
	    System.out.println("\u001B[33m\nWelcome to User's Status Management Menu. \nChoose Option Below\u001B[0m\n"
		    + "\u001B[32m\n1. Activate \u001B[0m"
		    + "\u001B[31m\n2. Deactivate \n0. Back to Previous Menu \u001B[0m");

	    choice = OperationFactory.getScannerInstance().next();

	    // switch statement for menu options
	    switch (choice) {
	    case "1":
		try {
		    // call activate user method
		    activateUser();
		} catch (UserException e) {
		    // call print menu exception method
		    this.printMenuException(e);
		}
		break;
	    case "2":
		try {
		    // call deactivate user method
		    deactivateUser();
		} catch (UserException e) {
		    // call print menu exception method
		    this.printMenuException(e);
		}
		break;
	    case "0":
		// exit
		System.out.println("\u001B[31m" + "You have chosen to exit\n" + "\u001B[0m");
		exCode = true;
		break;
	    default:
		// error message for invalid option
		System.out.println("Please enter a valid operation");
	    }
	}

	// return to previous menu
	System.out.println("\u001B[31m" + "Returning to Admin's Operation Menu" + "\u001B[0m");

	return true;
    }

    private boolean activateUser() throws UserException, AppException {
	// String variable to hold the current status of the user
	String currentStatus = "deactive";
	// String variable to hold the updated status of the user
	String updatedStatus = "active";

	// Printing the header of the list of deactivated users
	System.out.println("\u001B[36mList Of deactive Users\u001B[0m\n");
	// Retrieving the list of deactivated users
	UserExecutor.getInstance().retrieveRequiredUsersForAdmin(currentStatus);

	// Prompting the user to enter the username of the user they want to activate
	System.out.println("\n\u001B[32mEnter The ID You Want to Activate\u001B[0m\n");

	// Reading the username from the user
	int id = this.getUserId();

	// Checking if the entered username is valid or not
	if (!UserExecutor.getInstance().isValidUserId(id)) {
	    // If the username is not valid, printing the error message and returning false
	    System.out.println("\u001B[31m" + "Invalid User ID" + "\u001B[0m");
	    System.out.println("\u001B[31m" + "Returning to User's Status Update Menu.\n" + "\u001B[0m");
	    return false;
	}

	// Checking if the status of the user is deactivated or not
	if (!UserExecutor.getInstance().isValidUserStatus(id, currentStatus)) {

	    System.out.println("\u001B[31m" + "Status has not been updated because user already ACTIVE" + "\u001B[0m");
	    System.out.println("\u001B[31m" + "Returning to User's Status Update Menu.\n" + "\u001B[0m");
	    return false;
	}

	// Updating the status of the user to active
	UserExecutor.getInstance().updateUser(id, "user_status", updatedStatus);

	String username = UserExecutor.getInstance().getUsername(id);

	ClassifiedExecutor.getInstance().updateClassifiedByUserStatus(username, "classified_status", "pending");

	// Printing the success message after updating the status of the user
	System.out.println("\u001B[32m" + "Successfully Activated!" + "\u001B[0m");

	return true;
    }

    private boolean deactivateUser() throws UserException, AppException {

	// Constants for current status and updated status
	String currentStatus = "active";
	String updatedStatus = "deactive";

	// Prints the list of active users
	System.out.println("\u001B[36mList Of active Users\u001B[0m\n");
	UserExecutor.getInstance().retrieveRequiredUsersForAdmin(currentStatus);

	// Prompts user to enter the username they want to deactivate
	System.out.println("\n\u001B[32mEnter The ID You Want to Dectivate\u001B[0m\n");

	// Reading the username from the user
	int id = this.getUserId();

	// Validates the username
	if (!UserExecutor.getInstance().isValidUserId(id)) {
	    System.out.println("\u001B[31m" + "Invalid User ID" + "\u001B[0m");
	    System.out.println("\u001B[31m" + "Returning to User's Status Update Menu.\n" + "\u001B[0m");
	    return false;
	}

	// Validates the user status
	if (!UserExecutor.getInstance().isValidUserStatus(id, currentStatus)) {
	    System.out
		    .println("\u001B[31m" + "Status has not been updated because user already DEACTIVE" + "\u001B[0m");
	    System.out.println("\u001B[31m" + "Returning to User's Status Update Menu.\n" + "\u001B[0m");
	    return false;
	}

	// Calls the method to update the user status
	UserExecutor.getInstance().updateUser(id, "user_status", updatedStatus);

	String username = UserExecutor.getInstance().getUsername(id);

	ClassifiedExecutor.getInstance().updateClassifiedByUserStatus(username, "classified_status", updatedStatus);

	// Confirms the status change
	System.out.println("\u001B[32m" + "Successfully Deactivated!" + "\u001B[0m");

	return true;
    }

    // Implementation of Add/Remove Classified starts here.

    private boolean manageClassifiedAsAdminMenu() throws UserException, AppException {
	// variable to keep track if the user wants to exit
	boolean exCode = false;
	String choice = "";

	while (!exCode) {
	    // prompt user to choose between adding or removing classifieds
	    System.out.println("\u001B[33m" + "\nWelcome to Classified Management Menu. "
		    + "\nPlease choose an option below: \n" + "\u001B[0m" + "\u001B[32m" + "\n1. Add " + "\u001B[0m"
		    + "\u001B[31m" + "\n2. Remove \n0. Back to Previous Menu" + "\u001B[0m");

	    // get user choice
	    choice = OperationFactory.getScannerInstance().next();

	    // switch statement to handle user choice
	    switch (choice) {
	    case "1":
		// try-catch block for handling exceptions in adding classifieds
		try {
		    addClassifiedAsAdmin();
		} catch (UserException e) {
		    // print the exception message
		    this.printMenuException(e);
		} catch (ClassNotFoundException e) {
		    // TODO Auto-generated catch block
		    e.printStackTrace();
		}
		break;
	    case "2":
		// try-catch block for handling exceptions in removing classifieds
		try {
		    removeClassifiedAsAdmin();
		} catch (UserException e) {
		    // print the exception message
		    this.printMenuException(e);
		}
		break;
	    case "0":
		// user chooses to exit
		System.out.println("You have chosen to exit\n");
		exCode = true;
		break;
	    default:
		// if the user entered an invalid option
		System.out.println("Please enter a valid operation");
	    }
	}
	// inform user that they are returning to previous menu
	System.out.println("Returning to Previous Menu . . .\n");
	return true;

    }

    // Function to remove classified as Admin
    private boolean removeClassifiedAsAdmin() throws AppException, UserException {

	// Display the list of classifieds
	System.out.println("\u001B[36m" + "\nCurrent Classified List : \n" + "\u001B[0m");
	displayAllClassifiedsForAdmin();

	// Get the user input for classified Id
	System.out.println("\n\u001B[32m Please Enter The ID You Want to Remove\u001B[0m\n");
	int classifiedIdToRemove = this.getClassifiedId();

	// Check if the entered Id is present in the classified list
	if (!ClassifiedExecutor.getInstance().isPresent("classified", "classified_id", classifiedIdToRemove)) {
	    // If not present, print error message
	    System.out.println(
		    "Invalid ID Entered ===>" + classifiedIdToRemove + "<=== " + "\nReturning to Previous Menu\n");

	    return false;
	}

	// If present, remove the classified
	ClassifiedExecutor.getInstance().deleteClassified(classifiedIdToRemove);

	// Display updated classified list
	System.out.println("\u001B[36m" + "\nUpdated Classified List : \n" + "\u001B[0m");
	displayAllClassifiedsForAdmin();

	// Print success message
	System.out.println(
		"\u001B[32m" + "\nSuccessfully Removed Classified with ID : " + classifiedIdToRemove + "\u001B[0m");

	return true;
    }

    private boolean addClassifiedAsAdmin() throws AppException, UserException, ClassNotFoundException {

	// Print message to enter Classified Details
	System.out.println("\u001B[36m" + "\nPlease Enter Classified Details Below One by One" + "\u001B[0m");

	// Get Classified Headline
	System.out.println("\u001B[31m" + "\nEnter Classfied Headline:" + "\u001B[0m");
	System.out.println("\u001B[33m" + "[Headline Should not exceed 100 Characters]\n" + "\u001B[0m");
	String headline = this.getClassifiedHeadline();

	// Get Classified Product Name
	System.out.println("\u001B[31m" + "\nEnter Classfied Product Name:" + "\u001B[0m");
	System.out.println("\u001B[33m" + "[Product Name Should not exceed 50 Characters]\n" + "\u001B[0m");
	String productName = this.getClassifiedProductName();

	// Get Classified Brand
	System.out.println("\u001B[31m" + "\nEnter Classfied Brand:" + "\u001B[0m");
	System.out.println("\u001B[33m" + "[Brand Name Should not exceed 25 Characters]\n" + "\u001B[0m");
	String brand = this.getClassifiedBrand();

	// Get Classified Condition
	System.out.println("\u001B[31m" + "\nChoose Condition:" + "\u001B[0m");
	String productCondition = this.getClassifiedCondition();

	// Get Classified Description
	System.out.println("\u001B[31m" + "\nEnter Classfied Description:" + "\u001B[0m");
	System.out.println("\u001B[33m" + "[Description Should not exceed 500 Characters]\n" + "\u001B[0m");
	String classifiedDescription = this.getClassifiedDescription();

	// Get Classified Price
	System.out.println("\u001B[31m" + "\nEnter Classfied Price:" + "\u001B[0m");
	double price = this.getClassifiedPrice();

	// Get Classified Image URL
	System.out.println("\u001B[31m" + "\nEnter Classfied Image URL:" + "\u001B[0m");
	String imageurl = this.getClassifiedImageurl();

	// Set Classified Seller as Admin
	String seller = "admin";

	// Get Classified Category
	System.out.println("\u001B[31m" + "\nChoose Classfied Category by ID:\n" + "\u001B[0m");
	System.out.println("\u001B[36m" + "Available Categories:" + "\u001B[0m");
	ClassifiedListExecutor.getInstance().viewAllCategories();

	System.out.println("\n\u001B[32mChoose a Classfied Category by Entering ID Below\u001B[0m");
	int categoryId = this.getCategoryId();

	if (!ClassifiedListExecutor.getInstance().isValidCategory(categoryId)) {
	    System.out.println("\u001B[31m" + "Invalid ID Selected. Returning to previous menu" + "\u001B[0m");
	    return false;
	}

	// Create a new Classified object
	Classified newClassified = ShopInformation.getInstance().getClassifiedInstance(headline, productName, brand,
		productCondition, classifiedDescription, price, imageurl, seller, categoryId);

	// Call method to add Classified to the database
	ClassifiedExecutor.getInstance().addClassified(newClassified);

	// Print success message
	System.out.println("\u001B[32m" + "\nClassifed Added Successfully with Below Details :" + "\u001B[0m");
	ClassifiedExecutor.getInstance().retrieveClassified(newClassified.getClassifiedId());

	return true;
    }

    private boolean displayAllClassifiedsForAdmin() throws AppException {

	// Call method to retrieve all classifieds from database
	ClassifiedExecutor.getInstance().retrieveAllClassified();

	// Return true to indicate success of operation
	return true;
    }

    private boolean manageClassifiedCategoryMenu() throws AppException {
	// Declare a boolean variable to track whether the user wants to exit the menu
	boolean exCode = false;
	// Declare a String variable to store the user's choice
	String choice = "";

	// Keep looping until the user wants to exit the menu
	while (!exCode) {
	    // Print the menu options
	    System.out.println("\u001B[33m" + "\nWelcome to Category Management. " + "\nPlease choose an Option : \n"
		    + "\u001B[0m" + "\u001B[32m" + "\n1. Add " + "\u001B[0m" + "\u001B[33m" + "\n2. Update "
		    + "\u001B[0m" + "\u001B[31m" + "\n3. Remove \n0. Back to Previous Menu " + "\u001B[0m");
	    // Read the user's choice
	    choice = OperationFactory.getScannerInstance().next();

	    // Check the user's choice and perform the corresponding action
	    switch (choice) {
	    // Code for adding a classified category
	    case "1":
		try {
		    // Call the addCategory method to add a classified category
		    addCategory();
		} catch (UserException e) {
		    // If there is an error, call the printMenuException method to display the error
		    // message
		    this.printMenuException(e);
		}
		break;
	    // Code for updating a classified category
	    case "2":
		try {
		    // Call the updateCategory method to remove a classified category
		    updateCategory();
		} catch (UserException e) {
		    // If there is an error, call the printMenuException method to display the error
		    // message
		    this.printMenuException(e);
		}
		break;
	    // Code for removing a classified category
	    case "3":
		try {
		    // Call the removeCategory method to remove a classified category
		    removeCategory();
		} catch (UserException e) {
		    // If there is an error, call the printMenuException method to display the error
		    // message
		    this.printMenuException(e);
		}
		break;
	    // Code for exiting the menu
	    case "0":
		System.out.println("you have chosen exit\n");
		exCode = true;
		break;
	    // Handle invalid input
	    default:
		System.out.println("Please enter a valid operation");
		break;
	    }
	}
	// Print a message when the user returns to the previous menu
	System.out.println("Returning to Admin's Operation Menu\n");
	return true;
    }

    private boolean addCategory() throws UserException, AppException {

	// Prompt the user to enter category details
	System.out.println("\u001B[33m" + "\nPlease Enter Category Details Below :\n" + "\u001B[0m");

	// Prompt the user to enter category type/name
	System.out.println("\u001B[31m" + "Enter Category Type/Name:\n" + "\u001B[0m");
	String name = this.getCategoryName();

	if (ClassifiedListExecutor.getInstance().isPresent("category", "category_name", name)) {
	    // If the ID is invalid, notify the user and return to the previous menu
	    System.out.println("Name Already Exists!" + "\nReturning to Previous Menu\n");
	    return false;
	}

	// Create an instance of the ClassifiedCategory class
	ClassifiedList newcategory = ShopInformation.getInstance().getClassifiedCategoryInstance(name);

	// Add the new category to the list of categories
	ClassifiedListExecutor.getInstance().addCategory(newcategory);

	// Confirm to the user that the category has been added
	System.out.println("\u001B[32m" + "Successfully remove category with details below :\n" + "\u001B[0m");
	ClassifiedListExecutor.getInstance().viewCategory(newcategory.getCategoryId());
	return true;
    }

    private boolean updateCategory() throws AppException, UserException {

	// Display the list of categories to the user
	System.out.println("\n\u001B[36m" + "Category List\n" + "\u001B[0m");
	ClassifiedListExecutor.getInstance().viewAllCategories();

	// Prompt the user to enter the ID of the category to remove
	System.out.println("\u001B[31m" + "\nPlease enter Category Id to remove : \n" + "\u001B[0m");
	int idToUpdate = this.getCategoryId();
	// Check if the entered ID is valid
	if (!ClassifiedListExecutor.getInstance().isPresent("category", "category_id", idToUpdate)) {
	    // If the ID is invalid, notify the user and return to the previous menu
	    System.out.println("Invalid ID Entered ===>" + idToUpdate + "<=== " + "\nReturning to Previous Menu\n");
	    return false;
	}

	System.out.println("\u001B[31m" + "Enter New Category Name" + "\u001B[0m");
	String name = this.getCategoryName();

	if (ClassifiedListExecutor.getInstance().isPresent("category", "category_name", name)) {
	    // If the ID is invalid, notify the user and return to the previous menu
	    System.out.println("Name Already Exists!" + "\nReturning to Previous Menu\n");
	    return false;
	}

	ClassifiedListExecutor.getInstance().updateCategory(idToUpdate, "category_name", name);

	System.out.println("Successfully Updated");

	return true;
    }

    private boolean removeCategory() throws AppException, UserException {

	// Display the list of categories to the user
	System.out.println("\n\u001B[36m" + "Category List\n" + "\u001B[0m");
	ClassifiedListExecutor.getInstance().viewAllCategories();

	// Prompt the user to enter the ID of the category to remove
	System.out.println("\u001B[31m" + "\nPlease enter Category Id to remove : \n" + "\u001B[0m");
	int idToRemove = this.getCategoryId();

	// Check if the entered ID is valid
	if (!ClassifiedListExecutor.getInstance().isPresent("category", "category_id", idToRemove)) {
	    // If the ID is invalid, notify the user and return to the previous menu
	    System.out.println("Invalid ID Entered ===>" + idToRemove + "<=== " + "\nReturning to Previous Menu\n");
	    return false;
	}

	if (ClassifiedExecutor.getInstance().isPresent("classified", "category_id", idToRemove)) {
	    int count = ClassifiedExecutor.getInstance().getClassifiedCountByCategory(idToRemove);
	    System.out.println("\u001B[31m" + "Unable to Delete the Category! " + "\u001B[0m" + "\u001B[32m"
		    + "\nThere is total " + count + " Classified(s) present in Database with this Category."
		    + "\u001B[0m" + "\u001B[33m" + "\nYou can only Update this Category." + "\u001B[0m");
	    return false;
	}

	ClassifiedListExecutor.getInstance().removeCategory(idToRemove);
	// If the ID is valid, remove the category and notify the user
	System.out.println("\u001B[32m" + "Successfully removed category with ID : " + idToRemove + "\u001B[0m");

	System.out.println("\n\u001B[36m" + "Updated Category List\n" + "\u001B[0m");
	ClassifiedListExecutor.getInstance().viewAllCategories();

	return true;
    }

}
