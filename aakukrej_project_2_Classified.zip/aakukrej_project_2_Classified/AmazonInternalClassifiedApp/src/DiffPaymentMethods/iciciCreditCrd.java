package DiffPaymentMethods;

class iciciCreditCrd implements Payments {

    String cardDetails;

    public iciciCreditCrd(String cardDetails) {
	super();
	this.cardDetails = cardDetails;
    }

    
    
    
    public String getCardDetails() {
        return cardDetails;
    }




    public void setCardDetails(String cardDetails) {
        this.cardDetails = cardDetails;
    }


    
    public void add(String details) {
	System.out.println("[Card] " + details + " added successfully");
	onSuccess();
    }


    public void pay(int amount) {
	System.out.println("[Card] Payment  of amount " + amount + " Processed by Card Number " + cardDetails);
	onSuccess();
    }

    public void onSuccess() {
	System.out.println("[Card] Payment Successful");
    }

    public void onFailure() {
	System.out.println("[Card] Payment Failed");
    }

}
