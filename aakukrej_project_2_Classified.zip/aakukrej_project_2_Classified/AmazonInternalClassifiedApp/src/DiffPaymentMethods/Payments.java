package DiffPaymentMethods;

public interface Payments{
	
    	void add(String details);
    	void pay(int amount);
	void onSuccess();
	void onFailure();
}