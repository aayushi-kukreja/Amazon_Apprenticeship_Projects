package DiffPaymentMethods;

class DigiClick implements Payments {

	String payLink;

	public DigiClick(String payLink) {
		super();
		this.payLink = payLink;
	}

	public String getPayLink() {
		return payLink;
	}

	public void setPayLink(String payLink) {
		this.payLink = payLink;
	}

	public void add(String details) {
		System.out.println("[Digital] " + details + " added successfully");
		onSuccess();
	}

	public void pay(int amount) {
		System.out.println("[Digital] Payment  of amount " + amount + " Processed by UPI " + payLink);
		onSuccess();
	}

	public void onSuccess() {
		System.out.println("[Digital] Payment Successful");
	}

	public void onFailure() {
		System.out.println("[Digital] Payment Failed");
	}
}