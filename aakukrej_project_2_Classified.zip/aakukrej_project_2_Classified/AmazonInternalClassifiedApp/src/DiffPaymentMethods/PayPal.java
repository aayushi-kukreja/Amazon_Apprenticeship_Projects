package DiffPaymentMethods;

public class PayPal extends DigiClick {

    PayPal(String payLink) {
	super(payLink);
	System.out.println("[PayPal] Payment will be processed by #PayPal#");
}
}
