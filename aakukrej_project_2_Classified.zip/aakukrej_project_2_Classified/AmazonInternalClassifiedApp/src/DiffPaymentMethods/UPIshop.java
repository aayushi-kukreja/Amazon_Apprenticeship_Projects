package DiffPaymentMethods;

public class UPIshop implements PaymentAbstractFactory {
    
    public Payments createPaymentMethod(int type, String upiLink) {
	
	
	Payments payment = null;
	
	if(type == 1) {
		payment = new PayTM(upiLink);
	}else if(type == 2) {
		payment = new Gpay(upiLink);
	}else if(type == 3) {
		payment = new PhonePe(upiLink);
	}else {
		System.out.println("Invalid Choice");
	}
	
	return payment;
}

}
