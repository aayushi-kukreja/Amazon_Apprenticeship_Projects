package DiffPaymentMethods;

public class hdfcCard extends iciciCreditCrd {

    hdfcCard (String cardDetails) {
	super(cardDetails);
	System.out.println("[DebitCard] Payment will be processed by #Debit Card#");
    }

}
