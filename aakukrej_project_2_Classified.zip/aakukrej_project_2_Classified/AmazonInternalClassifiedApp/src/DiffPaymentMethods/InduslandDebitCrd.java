package DiffPaymentMethods;

public class InduslandDebitCrd extends iciciCreditCrd {

    InduslandDebitCrd (String cardDetails) {
	super(cardDetails);
	System.out.println("[AmericanExpressCard] Payment will be processed by ^American Express Card^");
    }
}
