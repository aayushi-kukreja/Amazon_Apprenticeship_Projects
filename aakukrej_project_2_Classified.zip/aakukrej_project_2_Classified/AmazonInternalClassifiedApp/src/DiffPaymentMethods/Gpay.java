package DiffPaymentMethods;

public class Gpay extends UPI {

    Gpay(String upiLink) {
	super(upiLink);
	System.out.println("[GooglePayUPI] Payment will be processed by *GooglePay UPI*");
    }

}
