package DiffPaymentMethods;

class UPI implements Payments{

	String upiLink;
	
	

	public UPI(String upiLink) {
	    super();
	    this.upiLink = upiLink;
	}

	


	public String getUpiLink() {
	    return upiLink;
	}


	public void setUpiLink(String upiLink) {
	    this.upiLink = upiLink;
	}


	
	 public void add (String details) {
		System.out.println("[UPI] " + details + " added successfully");
		onSuccess();
	    }
	
	public void pay(int amount) {
		System.out.println("[UPI] Payment  of amount "+amount+" Processed by UPI "+upiLink);
		onSuccess();
	}

	public void onSuccess() {
		System.out.println("[UPI] Payment Successful");
	}

	public void onFailure() {
		System.out.println("[UPI] Payment Failed");
	}
}
