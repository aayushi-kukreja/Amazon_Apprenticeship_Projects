package DiffPaymentMethods;

public class PayTM extends UPI {

    PayTM(String upiLink) {
	super(upiLink);
	System.out.println("[PayTMUPI] Payment will be processed by #PayTM UPI#");
    }

}
