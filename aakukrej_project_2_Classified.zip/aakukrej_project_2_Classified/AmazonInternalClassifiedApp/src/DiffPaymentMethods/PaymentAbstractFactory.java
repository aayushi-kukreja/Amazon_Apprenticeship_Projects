package DiffPaymentMethods;

public interface PaymentAbstractFactory {

    Payments createPaymentMethod(int type, String details);

  
}
