package DiffPaymentMethods;

public class PhonePe extends UPI{

    PhonePe (String upiLink) {
        super(upiLink);
	System.out.println("[PhonePeUPI] Payment will be processed by ^PhonePe UPI^");
}
}
