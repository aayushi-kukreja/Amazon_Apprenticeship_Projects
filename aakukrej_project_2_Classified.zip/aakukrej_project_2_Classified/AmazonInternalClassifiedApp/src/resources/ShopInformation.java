package resources;


import Administration.UserIdAdministrator;
import DiffPaymentMethods.PaymentAbstractFactory;
import exceptionHandling.AppException;


/*
 * Factory implementation 
 * Singleton 
 * 
 * single point creation of instances for all classes under package information
 * returns new instances 
 * 
 * InfoFactory is used in Operations for taking console inputs and returning appropriate instances 
 * also used to transmit data between operations & managers 
 * 
 */


public class ShopInformation {
	
	 private static ShopInformation infoFactory;

	  public static ShopInformation getInstance() {
	    if (infoFactory == null) {
	      infoFactory = new ShopInformation();
	    }
	    return infoFactory;
	  }
	
	

	
	public Classified getClassifiedInstance (String headline, String productName, String brand, String productCondition,
			String classifiedDescription, double price, String imageurl, String seller,
			int categoryId) throws AppException {
		
		int id = UserIdAdministrator.getInstance().getNewId("classified");
		
		return new Classified (id, headline, productName, brand, productCondition,
				classifiedDescription, price, imageurl, seller, categoryId);
		
	}
	
	public ClassifiedList getClassifiedCategoryInstance (String categoryName) throws AppException {
		
		int id = UserIdAdministrator.getInstance().getNewId("category");
		
		return new ClassifiedList (id, categoryName);
	}
	
	
	public Communication getCommunicationInstance(int classifiedId, String sender, String receiver, String message,
		 String time, String senderType) throws AppException {
		
		int id = UserIdAdministrator.getInstance().getNewId("communication");
		
		return new Communication (id, classifiedId, sender, receiver, message, time, senderType);
	}
	
	public Payment getPaymentInstance(int userId, String paymentMethod) throws AppException {
			
			int id = UserIdAdministrator.getInstance().getNewId("payment");
			
			return new Payment (id, userId, paymentMethod);
		}
		
	public Transaction getTransactionInstance(int userId, int classifiedId, int amount, int paymentId, String time) throws AppException {
			
			int id = UserIdAdministrator.getInstance().getNewId("transaction");
			
			return new Transaction (id, userId, classifiedId, amount, paymentId, time);
		}
		
	
	
	public User getUserInstance(int userId, String username, String firstName, String lastName, String email,
			String userPassword) throws AppException {
	
		return new User(userId, username, firstName, lastName, email, userPassword);
	
	}
	
	
	public PaymentDetails getPaymentInfoInstance(int userId, informations.payment.Payment payment) throws AppException {
		
		int id = UserIdAdministrator.getInstance().getNewId("payment");
		
		return new PaymentDetails (id, userId, payment);
	}
	
	
	
	

}
