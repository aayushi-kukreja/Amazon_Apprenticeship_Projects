package resources;

/**
 * 
 * The Classified class represents a classified advertisement that can be posted
 * on a website.
 * 
 * It contains various attributes of a classified, such as id, headline, product
 * name, brand, product condition, description, price, image URL, status, seller
 * and category.
 */
public class Classified {

    private int cID; // unique identifier for the classified
    private String title; // title of the classified
    private String productName; // name of the product being sold
    private String brand; // brand of the product being sold
    private String productCondition; // condition of the product being sold
    private String classifiedDescription; // description of the classified
    private double price; // price of the product being sold
    private String imageurl; // URL of the image associated with the classified
    private String classifiedStatus; // status of the classified (e.g. "pending", "approved", "rejected")
    private String seller; // username of the seller who posted the classified
    private int categoryId; // unique identifier of the category to which the classified belongs

    
    public Classified(int classifiedId, String headline, String productName, String brand, String productCondition,
	    String classifiedDescription, double price, String imageurl, String seller, int categoryId) {
	super();
	this.cID = classifiedId;
	this.title = headline;
	this.productName = productName;
	this.brand = brand;
	this.productCondition = productCondition;
	this.classifiedDescription = classifiedDescription;
	this.price = price;
	this.imageurl = imageurl;
	this.classifiedStatus = "pending"; // set initial status to "pending"
	this.seller = seller;
	this.categoryId = categoryId;
    }

    
    public int getClassifiedId() {
	return cID;
    }

    public void setClassifiedId(int classifiedId) {
	this.cID = classifiedId;
    }

    
    public String getHeadline() {
	return title;
    }

    
    public void setHeadline(String headline) {
	this.title = headline;
    }

    
    public String getProductName() {
	return productName;
    }

    
    public void setProductName(String productName) {
	this.productName = productName;
    }

    public String getBrand() {
	return brand;
    }

    public void setBrand(String brand) {
	// Set the brand attribute of the Classified object
	this.brand = brand;
    }

    public String getProductCondition() {
	return productCondition;
    }

    public void setProductCondition(String productCondition) {
	// Set the product condition attribute of the Classified object
	this.productCondition = productCondition;
    }

    public String getClassifiedDescription() {
	return classifiedDescription;
    }

    public void setClassifiedDescription(String classifiedDescription) {
	// Set the description attribute of the Classified object
	this.classifiedDescription = classifiedDescription;
    }

    public double getPrice() {
	return price;
    }

    public void setPrice(double price) {
	// Set the price attribute of the Classified object
	this.price = price;
    }

    public String getImageurl() {
	return imageurl;
    }

    public void setImageurl(String imageurl) {
	// Set the image URL attribute of the Classified object
	this.imageurl = imageurl;
    }

    public String getClassifiedStatus() {
	return classifiedStatus;
    }

    public void setClassifiedStatus(String classifiedStatus) {
	// Set the status attribute of the Classified object
	this.classifiedStatus = classifiedStatus;
    }

    public String getSeller() {
	return seller;
    }

    public void setSeller(String seller) {
	// Set the seller attribute of the Classified object
	this.seller = seller;
    }

    public int getCategoryId() {
	return categoryId;
    }

    public void setCategoryId(int categoryId) {
	// Set the category ID attribute of the Classified object
	this.categoryId = categoryId;
    }
}
