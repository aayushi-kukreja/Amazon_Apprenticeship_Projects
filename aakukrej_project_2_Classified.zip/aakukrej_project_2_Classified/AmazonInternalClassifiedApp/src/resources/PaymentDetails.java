package resources;

import DiffPaymentMethods.PaymentAbstractFactory;

public class PaymentDetails {
    
    private int paymentId;
    private int userId;
    private PaymentAbstractFactory paymetmethod;
    
    public PaymentDetails(int paymentId, int userId, PaymentAbstractFactory paymetmethod) {
	super();
	this.paymentId = paymentId;
	this.userId = userId;
	this.paymetmethod = paymetmethod;
    }
    public int getPaymentId() {
        return paymentId;
    }
    public void setPaymentId(int paymentId) {
        this.paymentId = paymentId;
    }
    public int getUserId() {
        return userId;
    }
    public void setUserId(int userId) {
        this.userId = userId;
    }
    public PaymentAbstractFactory getPaymetmethod() {
        return paymetmethod;
    }
    public void setPaymetmethod(PaymentAbstractFactory paymetmethod) {
        this.paymetmethod = paymetmethod;
    }
   
    

    
    
}
