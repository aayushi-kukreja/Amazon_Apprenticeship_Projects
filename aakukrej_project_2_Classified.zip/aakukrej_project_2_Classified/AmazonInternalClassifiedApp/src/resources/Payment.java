package resources;

public class Payment {

// Instance variables
    private int paymentId;
    private int userId;
    private String paymentMethod;

    public Payment(int paymentId, int userId, String paymentMethod) {
	super();
	this.paymentId = paymentId;
	this.userId = userId;
	this.paymentMethod = paymentMethod;
    }

// Getters and setters for instance variables
    public int getPaymentId() {
	return paymentId;
    }

    public void setPaymentId(int paymentId) {
	this.paymentId = paymentId;
    }

    public int getUserId() {
	return userId;
    }

    public void setUserId(int userId) {
	this.userId = userId;
    }

    public String getPaymentMethod() {
	return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
	this.paymentMethod = paymentMethod;
    }

}
