package resources;

public class Communication {

    private int communicationId; 
    private int classifiedId; 
    private String sender; 
    private String receiver; 
    private String message; 
    private String status; 
    private String time; 
    private String senderType; 
    /**
     * 
     * Constructs a new Communication object with the given communication ID,
     * classified ID, sender, receiver, message, time, and sender type. The status
     * of the communication is set to "unread" by default.
     * 
     * @param communicationId The ID of the communication
     * @param classifiedId    The ID of the classified ad associated with the
     *                        communication
     * @param sender          The user who sent the message
     * @param receiver        The user who received the message
     * @param message         The message sent
     * @param time            The time the message was sent
     * @param senderType      The type of user who sent the message (buyer/seller)
     */
    public Communication(int communicationId, int classifiedId, String sender, String receiver, String message,
	    String time, String senderType) {
	super();
	this.communicationId = communicationId;
	this.classifiedId = classifiedId;
	this.sender = sender;
	this.receiver = receiver;
	this.message = message;
	this.status = "unread";
	this.time = time;
	this.senderType = senderType;
    }
// Getters and setters for the class fields

    public int getCommunicationId() {
	return communicationId;
    }

    public void setCommunicationId(int communicationId) {
	this.communicationId = communicationId;
    }

    public int getClassifiedId() {
	return classifiedId;
    }

    public void setClassifiedId(int classifiedId) {
	this.classifiedId = classifiedId;
    }

    public String getSender() {
	return sender;
    }

    public void setSender(String sender) {
	this.sender = sender;
    }

    public String getReceiver() {
	return receiver;
    }

    public void setReceiver(String receiver) {
	this.receiver = receiver;
    }

    public String getMessage() {
	return message;
    }

    public void setMessage(String message) {
	this.message = message;
    }

    public String getStatus() {
	return status;
    }

    public void setStatus(String status) {
	this.status = status;
    }

    public String getTime() {
	return time;
    }

    public void setTime(String time) {
	this.time = time;
    }

    public String getSenderType() {
	return senderType;
    }

    public void setSenderType(String senderType) {
	this.senderType = senderType;
    }

}
