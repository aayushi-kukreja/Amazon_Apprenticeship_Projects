package resources;

import resources.Admin;

/**
 * The class Admin is a Singleton implementation which contains hard-coded Admin
 * Login Credentials and is the single place where Admin credentials are
 * defined. It supports only storage and retrieval of Admin Credentials, and
 * acts as POJO.
 **/

public class Admin {

    private static Admin admin;

    private String adminId;
    private String password;

    private Admin() {
    }

    // Method to return the instance of the Admin class
    public static Admin getAdminInstance() {
	// Check if the instance of the Admin class has been created
	if (admin == null) {
	    // Create a new instance of the Admin class
	    admin = new Admin();

	    // Set the adminId and password
	    admin.adminId = "admin";
	    admin.password = "admin";
	}
	// Return the instance of the Admin class
	return admin;
    }

    // Method to return the adminId
    public String getAdminId() {
	return adminId;
    }

    // Method to return the password
    public String getPassword() {
	return password;
    }
}
