package resources;

/**
 * 
 * A class representing a category for classified items.
 */
public class ClassifiedList {
    private int categoryId; // The unique identifier for the category
    private String categoryName; // The name of the category

    /**
     * 
     * Constructs a new ClassifiedCategory with the specified category ID and name.
     * 
     * @param categoryId   the unique identifier for the category
     * @param categoryName the name of the category
     */
    public ClassifiedList(int categoryId, String categoryName) {
	this.categoryId = categoryId;
	this.categoryName = categoryName;
    }

    /**
     * 
     * Returns the name of the category.
     * 
     * @return the name of the category
     */
    public String getCategoryName() {
	return categoryName;
    }

    /**
     * 
     * Sets the name of the category.
     * 
     * @param categoryName the name of the category
     */
    public void setCategoryName(String categoryName) {
	this.categoryName = categoryName;
    }

    /**
     * 
     * Returns the unique identifier for the category.
     * 
     * @return the unique identifier for the category
     */
    public int getCategoryId() {
	return categoryId;
    }

    /**
     * 
     * Sets the unique identifier for the category.
     * 
     * @param categoryId the unique identifier for the category
     */
    public void setCategoryId(int categoryId) {
	this.categoryId = categoryId;
    }
}
