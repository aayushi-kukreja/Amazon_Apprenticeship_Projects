package resources;

//This class represents a user of the system.
public class User {

//Unique ID of the user.
    private int userId;

//Username of the user.
    private String username;

//First name of the user.
    private String firstName;

//Last name of the user.
    private String lastName;

//Email address of the user.
    private String email;

//Password of the user.
    private String userPassword;

//Status of the user (active or deactive).
    private String status;

//Constructor to create a new User object.
    public User(int userId, String username, String firstName, String lastName, String email, String userPassword) {
	super();
	this.userId = userId;
	this.username = username;
	this.firstName = firstName;
	this.lastName = lastName;
	this.email = email;
	this.userPassword = userPassword;
	this.status = "active";
    }

// Getters and setters for instance variables

    public int getUserId() {
	return userId;
    }

    public void setUserId(int userId) {
	this.userId = userId;
    }

    public String getUsername() {
	return username;
    }

    public void setUsername(String username) {
	this.username = username;
    }

    public String getFirstName() {
	return firstName;
    }

    public void setFirstName(String firstName) {
	this.firstName = firstName;
    }

    public String getLastName() {
	return lastName;
    }

    public void setLastName(String lastName) {
	this.lastName = lastName;
    }

    public String getEmail() {
	return email;
    }

    public void setEmail(String email) {
	this.email = email;
    }

    public String getUserPassword() {
	return userPassword;
    }

    public void setUserPassword(String userPassword) {
	this.userPassword = userPassword;
    }

    public String getStatus() {
	return status;
    }

    public void setStatus(String status) {
	this.status = status;
    }

}
