
import Functionality.AppDriver;

public class Main {

    public static void main(String[] args) throws Exception {
	AppDriver appDriver = new AppDriver();
	appDriver.initiate();
    }

}