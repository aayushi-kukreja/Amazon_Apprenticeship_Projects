package database;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.ResultSetMetaData;
import java.sql.PreparedStatement;

public class Implementation {

    private static Implementation impl;

    // private constructor
    private Implementation() {
    }

    
    public static Implementation getInstance() {
	if (impl == null) {
	    impl = new Implementation();
	}
	return impl;
    }

    // executeWrite method to execute a write query (e.g. INSERT, UPDATE, DELETE)
    public boolean implWrite(String sqlQuery, Object[] params) throws SQLException, ClassNotFoundException {
	Connection conn = null;
	PreparedStatement preparedStatement = null;
	try {
	    // Get a connection from ConnectionManager
	    conn = ConnectionProvider.getConnection();

	    // Create a prepared statement using the connection and the provided SQL query
	    preparedStatement = conn.prepareStatement(sqlQuery);

	    // Set the parameters for the prepared statement
	    for (int i = 0; i < params.length; i++) {
		preparedStatement.setObject(i + 1, params[i]);
	    }

	    // Execute the update and get the result
	    int result = preparedStatement.executeUpdate();

	    // Check if the result is greater than zero, indicating the write query was
	    // successful
	    if (result != 0) {
		return false;
	    }
	    return true;
	} finally {
	    // close the Connection object
	    if (conn != null) {
		conn.close();
	    }

	    // close the PreparedStatement object
	    if (preparedStatement != null) {
		preparedStatement.close();
	    }
	}
    }

// executeRead method to execute a read query (e.g. SELECT)
    public boolean executeRead(String sqlQuery, String[] headers, Object[] params)
	    throws SQLException, ClassNotFoundException {
	Connection conn = null;
	PreparedStatement preparedStatement = null;
	ResultSet resultSet = null;
	try {
	    // Get a connection from ConnectionManager
	    conn = ConnectionProvider.getConnection();

	    // Create a prepared statement using the connection and the provided SQL query
	    preparedStatement = conn.prepareStatement(sqlQuery);

	    // Set the parameters for the prepared statement
	    for (int i = 0; i < params.length; i++) {
		preparedStatement.setObject(i + 1, params[i]);
	    }

	    // Execute the query and get the result set
	    resultSet = preparedStatement.executeQuery();

	    // Loop through the result set and print each row
	    while (resultSet.next()) {
		System.out.println();

		for (int i = 1; i <= headers.length; i++) {
		    System.out.println("\u001B[36m" + headers[i - 1] + ": " + "\u001B[0m" + resultSet.getString(i));
		}
	    }
	    System.out.println();

	    // Return true indicating that the read query was successful
	    return true;
	} finally {
	    // close the Connection object
	    if (conn != null) {
		conn.close();
	    }

	    // close the PreparedStatement object
	    if (preparedStatement != null) {
		preparedStatement.close();
	    }

	    // close the ResultSet object
	    if (resultSet != null) {
		resultSet.close();
	    }
	}
    }

    // This method retrieves data from a database and outputs the result as a table.
    // sqlQuery: the SQL query to execute
    // headers: the headers of the table
    // params: the parameters to substitute in the SQL query
    public boolean executeRetrieveAsTable(String sqlQuery, String[] headers, Object[] params)
	    throws SQLException, ClassNotFoundException {
	// Initialize the connection, prepared statement, and result set
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet resultSet = null;

	try {
	    // Get a connection to the database
	    conn = ConnectionProvider.getConnection();
	    // Prepare the SQL statement with the given parameters
	    pstmt = conn.prepareStatement(sqlQuery);

	    // Set the parameters in the prepared statement
	    for (int i = 0; i < params.length; i++) {
		pstmt.setObject(i + 1, params[i]);
	    }

	    // Execute the query and get the result set
	    resultSet = pstmt.executeQuery();
	    // Get metadata about the result set
	    ResultSetMetaData metaData = resultSet.getMetaData();

	    // Output the headers of the table
	    for (int i = 1; i <= headers.length; i++) {
		// Print the header with red color
		System.out.print(
			"\u001B[31m" + String.format("%-" + metaData.getColumnDisplaySize(i) + "s   ", headers[i - 1])
				+ "\u001B[0m");
	    }
	    System.out.println();

	    // Output the rows of the table
	    while (resultSet.next()) {
		System.out.println();

		for (int i = 1; i <= headers.length; i++) {
		    // Print each cell of the row
		    System.out.print(
			    String.format("%-" + metaData.getColumnDisplaySize(i) + "s   ", resultSet.getString(i)));
		}
	    }
	    System.out.println();

	    // Return true to indicate the success of the operation
	    return true;

	} finally {
	    // Close the connection, prepared statement, and result set
	    if (resultSet != null) {
		resultSet.close();
	    }
	    if (pstmt != null) {
		pstmt.close();
	    }
	    if (conn != null) {
		conn.close();
	    }
	}
    }

// This method checks if a record is present in the database based on the given
// SQL query and parameters.
// sqlQuery: the SQL query to execute
// param: the parameters to substitute in the SQL query
    public boolean isRecordPresent(String sqlQuery, Object[] param) throws SQLException, ClassNotFoundException {
	// Initialize the connection, prepared statement, and result set
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet resultSet = null;

	try {
	    // Get a connection to the database
	    conn = ConnectionProvider.getConnection();
	    // Prepare the SQL statement with the given parameters
	    pstmt = conn.prepareStatement(sqlQuery);

	    // Set the parameters in the prepared statement
	    for (int i = 0; i < param.length; i++) {
		pstmt.setObject(i + 1, param[i]);
	    }

	    // Execute the query and get the result set
	    resultSet = pstmt.executeQuery();

	    // Check if there is at least one record in the result set
	    if (resultSet.next()) {
		// Return true if there is at least one record
		return true;
	    }
	    // Return false if there is no record
	    return false;

	} finally {
	    // Close the connection, prepared statement, and result set
	    if (resultSet != null) {
		resultSet.close();
	    }
	    if (pstmt != null) {
		pstmt.close();
	    }
	    if (conn != null) {
		conn.close();
	    }
	}
    }

    public int getQueryNumber(String sqlQuery, Object[] param) throws SQLException, ClassNotFoundException {
	int result = -1;
	Connection conn = null;
	PreparedStatement preparedStatement = null;
	ResultSet resultSet = null;
	try {
	    // Get a connection to the database using the ConnectionManager class
	    conn = ConnectionProvider.getConnection();

	    // Create a prepared statement using the SQL query and the database connection
	    preparedStatement = conn.prepareStatement(sqlQuery);

	    // Loop through the input parameters and set each one in the prepared statement
	    for (int i = 0; i < param.length; i++) {
		// Set the value of the i-th parameter in the prepared statement, using 1-based
		// indexing
		preparedStatement.setObject(i + 1, param[i]);
	    }

	    // Execute the query and get the result set
	    resultSet = preparedStatement.executeQuery();

	    // Check if the result set has any rows
	    if (resultSet.next()) {
		// Get the first value of the first column in the result set
		result = resultSet.getInt(1);
	    }
	} finally {
	    // Close the result set, prepared statement, and connection objects
	    if (resultSet != null) {
		resultSet.close();
	    }
	    if (preparedStatement != null) {
		preparedStatement.close();
	    }
	    if (conn != null) {
		conn.close();
	    }
	}

	return result;
    }

    public String getQueryString(String sqlQuery, Object[] params) throws SQLException, ClassNotFoundException {
	String result = "";
	Connection conn = null;
	PreparedStatement preparedStatement = null;
	ResultSet resultSet = null;
	try {
	    // Get a connection to the database using the ConnectionManager class
	    conn = ConnectionProvider.getConnection();

	    // Create a prepared statement using the SQL query and the database connection
	    preparedStatement = conn.prepareStatement(sqlQuery);

	    // Loop through the input parameters and set each one in the prepared statement
	    for (int i = 0; i < params.length; i++) {
		// Set the value of the i-th parameter in the prepared statement, using 1-based
		// indexing
		preparedStatement.setObject(i + 1, params[i]);
	    }

	    // Execute the query and get the result set
	    resultSet = preparedStatement.executeQuery();

	    // Check if the result set has any rows
	    if (resultSet.next()) {
		// Get the value of the first column in the first row of the result set
		result = resultSet.getString(1);
	    }
	} finally {
	    // Close the result set, prepared statement, and connection objects
	    if (resultSet != null) {
		resultSet.close();
	    }
	    if (preparedStatement != null) {
		preparedStatement.close();
	    }
	    if (conn != null) {
		conn.close();
	    }
	}

	return result;
    }

    public ResultSet getResultSet(String sqlQuery, Object[] param) throws SQLException, ClassNotFoundException {
	// Declare variables for connection, prepared statement, and result set
	Connection conn = null;
	PreparedStatement preparedStatement = null;
	ResultSet resultSet = null;

	try {
	    // Get a connection to the database using the ConnectionManager class
	    conn = ConnectionProvider.getConnection();

	    // Create a prepared statement using the SQL query and the database connection
	    preparedStatement = conn.prepareStatement(sqlQuery);

	    // Loop through the input parameters and set each one in the prepared statement
	    for (int i = 0; i < param.length; i++) {
		// Set the value of the i-th parameter in the prepared statement, using 1-based
		// indexing
		preparedStatement.setObject(i + 1, param[i]);
	    }

	    // Execute the query and get the result set
	    resultSet = preparedStatement.executeQuery();

	    // Return the result set to the caller
	    return resultSet;
	} catch (SQLException | ClassNotFoundException e) {
	    // If an exception is thrown, re-throw it to the caller
	    throw e;
	} finally {
	    // Close the result set, prepared statement, and connection objects
	    if (resultSet != null) {
		resultSet.close();
	    }
	    if (preparedStatement != null) {
		preparedStatement.close();
	    }
	    if (conn != null) {
		conn.close();
	    }
	}
    }

}
