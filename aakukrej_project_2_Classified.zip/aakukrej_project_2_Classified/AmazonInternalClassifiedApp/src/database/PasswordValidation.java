 package database;

import java.util.regex.Pattern;

public class PasswordValidation {

    private static int Password_size = 12;
    public static boolean isValidPassword(String password) {
	if (password.length() < Password_size) {
	    return false;
	}

	int cCount = 0;
	int nCount = 0;

	for (int i = 0; i < password.length(); i++) {
	    char ch = password.charAt(i);

	    if (isNumeric(ch)) {
		nCount++;
	    } else if (isAlphabet(ch)) {
		cCount++;
	    } else {
		return false;
	    }
	}

	return (cCount >= 2 && nCount >= 2);
    }

    // This method checks if the given character is an alphabet.
    public static boolean isAlphabet(char ch) {
	ch = Character.toUpperCase(ch);
	return (ch >= 'A' && ch <= 'Z');
    }

    // This method checks if the given string contains only alphabetic characters
    public static boolean isAlphabetic(String stringValue) {
	for (int i = 0; i < stringValue.length(); i++) {
	    if (!isAlphabet(stringValue.charAt(i))) {
		return false;
	    }
	}
	return true;
    }

    // This method checks if the given character is a digit
    public static boolean isNumeric(char ch) {
	return (ch >= '0' && ch <= '9');
    }

    // This method checks if the given string contains only numeric characters
    public static boolean isNumeric(String stringValue) {
	for (int i = 0; i < stringValue.length(); i++) {
	    if (!isNumeric(stringValue.charAt(i))) {
		return false;
	    }
	}
	return true;
    }

    // This method checks if the given string is blank or empty
    public static boolean isBlank(String input) {
	if (input.trim().equals("")) {
	    return true;
	}
	return false;
    }

    // This method checks if the given double is blank or empty
    public static boolean isBlank(double input) {
	String st = String.valueOf(input);

	if (st.trim().equals("")) {
	    return true;
	}
	return false;
    }

    // This method checks if the given email address is valid
    public static boolean isValidEmail(String emailAddress) {
	if (emailAddress == null) {
	    return false;
	}

	String emailRegex = "[a-zA-Z.0-9_]+@[a-zA-Z0-9_]+\\.[a-zA-Z]{2,7}$";

	Pattern pat = Pattern.compile(emailRegex);

	return pat.matcher(emailAddress).matches();
    }

    // This method checks if the given first name is of a valid length
    public static boolean isValidNameLength(String firstName) {
	if (firstName.length() < 50) {
	    return true;
	}
	return false;
    }

    // This method checks if the given passwords match
    public static boolean arePasswordsMatching(String password, String confirmedPassword) {
	return password.equals(confirmedPassword);
    }

    // This method checks if the given user ID is of a valid length
    public static boolean isValidUserIdLength(int userId) {
	return userId <= 1000000000 && userId >= 99999999;
    }

    // This method checks if the given number is positive
    public static boolean isPositive(int number) {
	return number > 0;
    }

    // Returns true if the given long number is positive, otherwise returns false.
    public static boolean isPositive(Long longNumber) {
	return longNumber > 0;
    }

    // Returns true if the given username is valid, otherwise returns false.
    // A valid username must be at least 5 characters long and less than 30
    // characters long,
    // and can only contain letters and numbers.
    public static boolean isValidUsername(String username) {
	if (username.length() < 5 || username.length() >= 30) { // Check username length
	    return false;
	}

	for (char c : username.toCharArray()) { // Check username characters
	    if (!Character.isLetterOrDigit(c)) {
		return false;
	    }
	}

	return true;
    }

    // Returns true if the given date string is a valid date, otherwise returns
    // false.
    // The date string must be in the format "yyyy-MM-dd".
    public static boolean isValidDate(String dateStr) {
	// Check that the date string has the correct format
	if (dateStr == null || !dateStr.matches("^\\d{4}-\\d{2}-\\d{2}$")) {
	    System.out.println("Invalid date format: " + dateStr + ". Please use the format 'YYYY-MM-DD'.");
	    return false;
	}

	// Parse the year, month, and day values from the date string
	int year = Integer.parseInt(dateStr.substring(0, 4));
	int month = Integer.parseInt(dateStr.substring(5, 7));
	int day = Integer.parseInt(dateStr.substring(8, 10));

	// Check that the year, month, and day values are within valid ranges
	if (year < 1000 || year > 9999) {
	    System.out.println("Invalid year value: " + year + ". Year must be a 4-digit number.");
	    return false;
	}
	if (month < 1 || month > 12) {
	    System.out.println("Invalid month value: " + month + ". Month must be between 1 and 12.");
	    return false;
	}
	if (day < 1 || day > 31) {
	    System.out.println("Invalid day value: " + day + ". Day must be between 1 and 31.");
	    return false;
	}

	// Check for months with less than 31 days
	if (day == 31 && (month == 4 || month == 6 || month == 9 || month == 11)) {
	    System.out.println("Invalid date: " + dateStr + ". Month " + month + " does not have 31 days.");
	    return false;
	}

	// Check for February
	if (month == 2) {
	    // Leap year
	    if (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0)) {
		if (day > 29) {
		    System.out.println("Invalid date: " + dateStr + ". February " + year + " has at most 29 days.");
		    return false;
		}
		// Not a leap year
	    } else {
		if (day > 28) {
		    System.out.println("Invalid date: " + dateStr + ". February " + year + " has at most 28 days.");
		    return false;
		}
	    }
	}

	// Date is valid
	return true;
    }

    public static boolean isValidClassifiedHeadline(String headline) {
	// Headline must be at least 2 characters long and less than or equal to 100
	if (headline.length() > 1 && headline.length() <= 100) {
	    return true;
	}
	return false;
    }

    public static boolean isValidClassifiedProductName(String productName) {
	// Product name must be at least 2 characters long and less than or equal to 50
	if (productName.length() > 1 && productName.length() <= 50) {
	    return true;
	}
	return false;
    }

    public static boolean isValidClassifiedBrand(String brand) {
	// Brand name must be at least 2 characters long and less than or equal to 25
	if (brand.length() > 1 && brand.length() <= 25) {
	    return true;
	}
	return false;
    }

    public static boolean isValidClassifiedDescription(String description) {
	// Description must be at least 2 characters long and less than or equal to 500
	if (description.length() > 1 && description.length() <= 500) {
	    return true;
	}
	return false;
    }

    public static boolean isValidClassifiedUrl(String url) {
	// URL must be at least 2 characters long and less than or equal to 100
	if (url.length() > 1 && url.length() <= 100) {
	    return true;
	}
	return false;
    }

    public static boolean isValidMessage(String message) {
	// Message must be at least 2 characters long and less than or equal to 300
	if (message.length() > 1 && message.length() <= 300) {
	    return true;
	}
	return false;
    }

    public static boolean isValidCardLength(String details) {
	// Details must be exactly 16 characters long to be considered valid
	return details.length() == 16;
    }

}
