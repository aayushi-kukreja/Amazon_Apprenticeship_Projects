package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionProvider {

	private static Connection con;

	public ConnectionProvider() {
	}

	public static Connection getConnection() throws SQLException, ClassNotFoundException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");

			con = DriverManager.getConnection("jdbc:mysql://localhost:330" + "" + "" + "" + "6/AICDB", "root",
					"MyPassword123@123");

			return con;
		} catch (Exception e) {

			System.out.println("Connection Issue Found");
			e.printStackTrace();

			throw e;
		}
	}
}
