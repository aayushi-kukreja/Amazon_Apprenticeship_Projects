package exceptionHandling;

/*
 * 
 * catch exceptions related to user inputs 
 * input mismatch, invalid inputs
 * 
 */

public class UserException extends Exception {

    private static final long serialVersionUID = 1L;

    public UserException(String message) {
	// some message & info to be displayed
	super(message);
    }

}