package exceptionHandling;

/*
 * 
 * system exceptions related to DB or class or file
 * throw a custom message      
 *
 */

public class AppException extends Exception {

    private static final long serialVersionUID = 1L;

    public AppException(String message) {
	// some message & info to be displayed
	super(message);
    }

}
