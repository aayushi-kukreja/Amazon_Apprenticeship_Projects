package Administration;

import exceptionHandling.AppException;
import resources.Payment;


public class PaymentExecutor extends DefaultExecutor {

    private static PaymentExecutor paymentManager;

    public static PaymentExecutor getInstance() {
	if (paymentManager == null) {

	    paymentManager = new PaymentExecutor();
	}

	return paymentManager;
    }

    public boolean createPayment(Payment payment) throws AppException {

	String sqlQuery = "INSERT INTO payment (payment_id, user_id, payment_method) VALUES (?,?,?)";

	Object[] params = { payment.getPaymentId(), payment.getUserId(), payment.getPaymentMethod() };

	this.executeWrite(sqlQuery, params);

	return true;

    }

    public boolean retrieveAllPaymentMethodForUser(int userId) throws AppException {

	String sqlQuery = "SELECT payment_id, payment_method from payment " + "WHERE user_id = ? ";

	if (!this.hasResult(sqlQuery, new Object[] { userId })) {
	    System.out.println("No Payment Method Found! Please add a Payment method.");
	}

	String [] headers = {"ID", "PAYMENT METHOD"};
	this.executeReadAsTable(sqlQuery, headers, new Object[] { userId });

	return true;

    }
    
 

    public boolean deletePaymentMethod(int id) throws AppException {
	String sqlQuery = "DELETE FROM payment WHERE payment_id = ?";
	this.executeWrite(sqlQuery, new Object[] { id });
	return true;
    }
    
    public boolean isValidPaymentMethod(int paymentId, int userId) throws AppException {
	
	String sql = "SELECT * FROM payment WHERE payment_id = ? AND user_id = ? ";
	
	return this.hasResult(sql, new Object [] {paymentId, userId});
}
    
    
    
    
    

}