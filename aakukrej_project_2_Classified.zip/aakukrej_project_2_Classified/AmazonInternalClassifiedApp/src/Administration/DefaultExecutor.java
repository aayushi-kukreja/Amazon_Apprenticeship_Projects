package Administration;

import exceptionHandling.AppException;

import java.sql.ResultSet;
import java.sql.SQLException;

import database.Implementation;

public class DefaultExecutor {

	public static DefaultExecutor getInstance() throws AppException {
		throw new AppException("Class not implemented");
	}

	protected void executeWrite(String sqlQuery, Object[] param) throws AppException {
		try {
			Implementation.getInstance().implWrite(sqlQuery, param);
		} catch (SQLException e) {
			throw new AppException("SQL exception");
		} catch (ClassNotFoundException e) {
			throw new AppException("Class not found");
		}
	}

//Executes an sqlQuery, and adds fields as the header for each column
	protected void executeRead(String sqlQuery, String[] fields, Object[] param) throws AppException {
		try {
			Implementation.getInstance().executeRead(sqlQuery, fields, param);
		} catch (SQLException e) {
			throw new AppException("SQL exception");
		} catch (ClassNotFoundException e) {
			throw new AppException("Class not found");
		}
	}

	protected void executeReadAsTable(String sqlQuery, String[] fields, Object[] param) throws AppException {
		try {
			Implementation.getInstance().executeRetrieveAsTable(sqlQuery, fields, param);
		} catch (SQLException e) {
			throw new AppException("SQL exception");
		} catch (ClassNotFoundException e) {
			throw new AppException("Class not found");
		}
	}

	// Checks whether the sqlQuery has a non-empty result
	protected boolean hasResult(String sqlQuery, Object[] param) throws AppException {
		try {
			return Implementation.getInstance().isRecordPresent(sqlQuery, param);
		} catch (SQLException e) {
			throw new AppException("SQL exception");
		} catch (ClassNotFoundException e) {
			throw new AppException("Class not found");
		}
	}

	// Gets the ResultSet from a sqlQuery
	protected ResultSet getResultSet(String query, Object[] param) throws AppException {
		try {
			return Implementation.getInstance().getResultSet(query, param);
		} catch (SQLException e) {
			throw new AppException("SQL exception");
		} catch (ClassNotFoundException e) {
			throw new AppException("Class not found");
		}
	}

	// Gets the first Integer result from a sqlQuery
	protected int getQueryNumber(String sqlQuery, Object[] param) throws AppException {
		try {
			return Implementation.getInstance().getQueryNumber(sqlQuery, param);
		} catch (SQLException e) {
			throw new AppException("SQL exception");
		} catch (ClassNotFoundException e) {
			throw new AppException("Class not found");
		}
	}

	// Gets next String in a ResultSet for given columnIndex
	protected String getString(String query, Object[] param) throws AppException {
		try {
			return Implementation.getInstance().getQueryString(query, param);
		} catch (SQLException e) {
			throw new AppException("SQL exception");
		} catch (ClassNotFoundException e) {
			throw new AppException("Class not found");
		}
	}

	public boolean isPresent(String tableName, String field, String value) throws AppException {
		String query = "SELECT * FROM " + tableName + " WHERE " + field + "=?";
		Object[] param = new Object[] { value };
		try {
			return Implementation.getInstance().isRecordPresent(query, param);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new AppException("Invalid SQL");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			throw new AppException("SQL Class not found");
		}
	}

	public boolean isPresent(String tableName, String field, int value) throws AppException {
		String query = "SELECT * FROM " + tableName + " WHERE " + field + "=?";
		try {
			return Implementation.getInstance().isRecordPresent(query, new Object[] { value });
		} catch (SQLException e) {
			e.printStackTrace();
			throw new AppException("Invalid SQL");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			throw new AppException("SQL Class not found");
		}
	}

	// Checks for next row presence in a ResultSet
	protected boolean isNextPresent(ResultSet resultSet) throws AppException {
		try {
			return resultSet.next();
		} catch (SQLException e) {
			throw new AppException("SQL exception");
		}
	}

	// Moved ResultSet Cursor to previous position
	protected boolean goToPrevious(ResultSet resultSet) throws AppException {
		try {
			return resultSet.previous();
		} catch (SQLException e) {
			throw new AppException("SQL exception");
		}
	}
}
