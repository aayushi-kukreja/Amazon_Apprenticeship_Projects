package Administration;

import exceptionHandling.AppException;
import resources.Classified;

public class ClassifiedExecutor extends DefaultExecutor {

	private static ClassifiedExecutor classifiedManager;

	public static ClassifiedExecutor getInstance() {
		if (classifiedManager == null) {
			classifiedManager = new ClassifiedExecutor();
		}
		return classifiedManager;
	}

	public boolean addClassified(Classified classified) throws AppException {

		String sqlQuery = "INSERT INTO classified (classified_id, headline, product_name, brand, product_condition, classified_description, price, seller, imageurl, classified_status, category_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		Object[] params = { classified.getClassifiedId(), classified.getHeadline(), classified.getProductName(),
				classified.getBrand(), classified.getProductCondition(), classified.getClassifiedDescription(),
				classified.getPrice(), classified.getSeller(), classified.getImageurl(),
				classified.getClassifiedStatus(), classified.getCategoryId() };

		this.executeWrite(sqlQuery, params);
		return true;
	}

	public boolean retrieveRequiredClassifiedsForAdmin(String status) throws AppException {

		String sqlQuery = "SELECT classified_id, classified_status " + "FROM classified "
				+ "WHERE classified_status = ?";

		if (!this.hasResult(sqlQuery, new Object[] { status })) {
			System.out.println("No available Records found");
			return false;
		}

		String[] headers = { "ID", "Status" };
		this.executeReadAsTable(sqlQuery, headers, new Object[] { status });

		return true;
	}

	public boolean retrieveClassified(int id) throws AppException {
		String sqlQuery = "SELECT cl.classified_id, cl.headline, cl.product_name, cl.brand, cl.product_condition, cl.price, cl.classified_description, cl.seller, cl.imageurl, ca.category_name "
				+ "FROM classified cl " + "JOIN category ca ON cl.category_id = ca.category_id "
				+ "WHERE cl.classified_id = ?";

		Object[] params = { id };

		if (!this.hasResult(sqlQuery, params)) {
			System.out.println("No available Records found");
			return false;
		}

		String[] headers = { "ID", "TITLE", "PRODUCT", "BRAND", "CONDITION", "PRICE", "DESCRIPTION", "SELLER", "IMAGE",
				"CATEGORY" };
		this.executeRead(sqlQuery, headers, params);

		return true;
	}

	public boolean updateClassified(int classifiedId, String field, String newValue) throws AppException {

		String sqlQuery = "UPDATE classified SET " + field + "= ? WHERE classified_id = ?";
		Object[] params = { newValue, classifiedId };

		this.executeWrite(sqlQuery, params);

		return true;
	}

	public boolean updateClassifiedByUserStatus(String username, String field, String newValue) throws AppException {

		String sqlQuery = "UPDATE classified SET " + field + " = ? WHERE seller = ?";
		Object[] params = { newValue, username };

		this.executeWrite(sqlQuery, params);

		return true;
	}

	public boolean deleteClassified(int classifiedId) throws AppException {
		String sqlQuery = "DELETE FROM classified WHERE classified_id=?";
		Object[] params = { classifiedId };

		this.executeWrite(sqlQuery, params);
		return true;
	}

	public boolean isValidClassifiedId(int classifiedId) throws AppException {
		return this.isPresent("classified", "classified_id", classifiedId);
	}

	public boolean isValidSeller(String seller) throws AppException {
		return this.isPresent("classified", "seller", seller);
	}

	public boolean isValidCurrentClassifiedStatus(int id, String status) throws AppException {

		String sqlQuery = "SELECT classified_id, classified_status "
				+ "FROM classified WHERE classified_id= ? AND classified_status= ?";
		Object[] params = { id, status };

		return this.hasResult(sqlQuery, params);

	}

	public boolean retrieveAllClassified() throws AppException {
		String sqlQuery = "SELECT cl.classified_id, cl.headline, cl.product_name, cl.brand, cl.product_condition, cl.price, cl.classified_description, cl.seller, cl.imageurl, ca.category_name "
				+ "FROM classified cl " + "JOIN category ca ON cl.category_id = ca.category_id";

		if (!this.hasResult(sqlQuery, new Object[] {})) {
			System.out.println("No Records Found!");
		}

		String[] headers = { "ID", "TITLE", "PRODUCT", "BRAND", "CONDITION", "DESCRIPTION", "PRICE", "SELLER", "IMAGE",
				"CATEGORY" };

		this.executeRead(sqlQuery, headers, new Object[] {});
		return true;

	}

	public String getSellerName(int id) throws AppException {
		String sqlQuery = "SELECT seller FROM classified WHERE classified_id = ?";
		return this.getString(sqlQuery, new Object[] { id });
	}

	public String getProductName(int id) throws AppException {

		String sqlQuery = "SELECT product_name FROM classified WHERE classified_id = ?";

		return this.getString(sqlQuery, new Object[] { id });
	}

	public int getClassifiedCountByCategory(int id) throws AppException {
		String sqlQuery = "SELECT COUNT(*) FROM classified WHERE category_id = ? GROUP BY category_id";

		return this.getQueryNumber(sqlQuery, new Object[] { id });
	}

	public boolean isValidSellerForBuyer(String username, String seller) throws AppException {
		createViewValidClassifiedForBuyer(username);
		return this.isPresent("valid_classified_for_buyer_view", "seller", seller);
	}

	void createViewValidClassifiedForBuyer(String username) throws AppException {

		String sqlQuery = "DROP VIEW IF EXISTS valid_classified_for_buyer_view";

		this.executeWrite(sqlQuery, new Object[] {});

		sqlQuery = "CREATE VIEW valid_classified_for_buyer_view AS\n"
				+ "SELECT cl.classified_id, cl.headline, cl.product_name, cl.brand, cl.product_condition, cl.classified_description, cl.price, cl.seller, cl.imageurl, cl.category_id \n"
				+ "FROM classified cl\n" + "JOIN user u ON cl.seller = u.username\n"
				+ "WHERE u.user_status = ? AND cl.classified_status = ? AND u.username != ?;";

		Object[] params = { "active", "approved", username };

		this.executeWrite(sqlQuery, params);

	}

	public boolean retrieveAllClassifiedByUser(String username) throws AppException {
		String sqlQuery = "SELECT cl.classified_id, cl.headline, cl.product_name, cl.brand, cl.product_condition, cl.classified_description, cl.price, cl.imageurl, cl.classified_status, ca.category_name "
				+ "FROM classified cl " + "JOIN category ca " + "ON cl.category_id = ca.category_id "
				+ "WHERE seller = ?";

		String[] headers = { "ID", "TITLE", "PRODUCT NAME", "BRAND", "CONDITION", "DESCRIPTION", "PRICE", "IMAGE",
				"STATUS", "CATEGORY" };

		if (!this.hasResult(sqlQuery, new Object[] { username })) {

			System.out.println("No records Found!");
			return false;
		}

		this.executeRead(sqlQuery, headers, new Object[] { username });
		return true;
	}

	public boolean retrieveAllClassifiedForUser(String username) throws AppException {

		createViewValidClassifiedForBuyer(username);

		String sqlQuery = "SELECT cl.classified_id, cl.price, cl.product_name, cl.headline "
				+ "FROM valid_classified_for_buyer_view cl ";

		String[] headers = { "ID", "PRICE", "PRODUCT", "TITLE" };

		this.executeReadAsTable(sqlQuery, headers, new Object[] {});
		return true;

	}

	public boolean retrieveClassifiedPriceLowToHigh(String username) throws AppException {

		createViewValidClassifiedForBuyer(username);

		String sqlQuery = "SELECT cl.classified_id, cl.price, cl.product_name, cl.headline "
				+ "FROM valid_classified_for_buyer_view cl " + "ORDER BY cl.price ASC";

		String[] headers = { "ID", "PRICE", "PRODUCT", "TITLE" };

		this.executeReadAsTable(sqlQuery, headers, new Object[] {});
		return true;
	}

	public boolean retrieveClassifiedPriceHighToLow(String username) throws AppException {
		createViewValidClassifiedForBuyer(username);

		String sqlQuery = "SELECT cl.classified_id, cl.price, cl.product_name, cl.headline "
				+ "FROM valid_classified_for_buyer_view cl " + "ORDER BY cl.price DESC";

		String[] headers = { "ID", "PRICE", "PRODUCT", "TITLE" };

		this.executeReadAsTable(sqlQuery, headers, new Object[] {});
		return true;
	}

	public boolean retreiveSeller(String username) throws AppException {
		createViewValidClassifiedForBuyer(username);
		String sqlQuery = "SELECT seller, COUNT(classified_id) " + "FROM valid_classified_for_buyer_view "
				+ "GROUP BY seller";

		String[] headers = { "SELLER", "TOTAL PRODUCT" };

		this.executeReadAsTable(sqlQuery, headers, new Object[] {});

		return true;
	}

	public boolean retrieveClassifiedBySeller(String seller) throws AppException {
		String sqlQuery = "SELECT cl.classified_id, cl.price, cl.product_name, cl.headline "
				+ "FROM valid_classified_for_buyer_view cl " + "WHERE cl.seller = ?";

		Object[] params = { seller };

		String[] headers = { "ID", "PRICE", "PRODUCT", "TITLE" };

		this.executeReadAsTable(sqlQuery, headers, params);
		return true;
	}

	public boolean retrieveClassifiedByCategory(String category) throws AppException {
		String sqlQuery = "SELECT cl.classified_id, cl.price, cl.product_name, cl.headline "
				+ "FROM valid_classified_for_buyer_view cl " + "JOIN category ca ON cl.category_id = ca.category_id "
				+ "WHERE ca.category_name = ?";

		String[] headers = { "ID", "PRICE", "PRODUCT", "TITLE" };

		Object[] params = { category };
		this.executeReadAsTable(sqlQuery, headers, params);
		return true;
	}

	public boolean getClassifiedDetails(String username, int id) throws AppException {

		createViewValidClassifiedForBuyer(username);

		String sqlQuery = "SELECT cl.classified_id, cl.headline, cl.product_name, cl.brand, cl.product_condition, cl.classified_description, cl.price, cl.seller, cl.imageurl, ca.category_name "
				+ "FROM valid_classified_for_buyer_view cl " + "JOIN category ca ON cl.category_id = ca.category_id "
				+ "WHERE classified_id = ? ";

		String[] headers = { "ID", "TITLE", "NAME", "BRAND", "CONDITION", "DESCRIPTION", "PRICE", "SELLER", "IMAGE",
				"CATEGORY" };

		this.executeRead(sqlQuery, headers, new Object[] { id });
		return true;

	}

	public boolean isValidClassifiedIdForBuyer(String username, int classifiedId) throws AppException {
		createViewValidClassifiedForBuyer(username);
		return this.isPresent("valid_classified_for_buyer_view", "classified_id", classifiedId);
	}

	public boolean isClassifiedByUser(String sender, int classifiedId) throws AppException {

		String sqlQuery = "SELECT classified_id FROM classifed " + "WHERE seller = ? AND classified_id = ?";

		Object[] params = { sender, classifiedId };

		return this.hasResult(sqlQuery, params);
	}

	public int getPrice(int classifiedId) throws AppException {
		String sql = "SELECT price from classified WHERE classified_id =?";

		return this.getQueryNumber(sql, new Object[] { classifiedId });
	}

}
