package Administration;

import exceptionHandling.AppException;

public class UserIdAdministrator extends DefaultExecutor {

	private static UserIdAdministrator idManager;

	public static UserIdAdministrator getInstance() {
		if (idManager == null) {
			idManager = new UserIdAdministrator();
		}
		return idManager;
	}

	public int getNewId(String objectName) throws AppException {
		String sqlQuery = "SELECT latest_id FROM id_generator WHERE object_name=?";

		int newId = this.getQueryNumber(sqlQuery, new Object[] { objectName }) + 1;

		sqlQuery = "UPDATE id_generator SET latest_id = ? WHERE object_name = ?";
		this.executeWrite(sqlQuery, new Object[] { newId, objectName });

		return newId;
	}

}