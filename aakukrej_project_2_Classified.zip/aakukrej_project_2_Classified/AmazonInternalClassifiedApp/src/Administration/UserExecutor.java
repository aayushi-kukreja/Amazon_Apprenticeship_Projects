package Administration;

import exceptionHandling.AppException;
import resources.User;

public class UserExecutor extends DefaultExecutor {

	private static UserExecutor userManager;

	public static UserExecutor getInstance() {
		if (userManager == null) {
			userManager = new UserExecutor();
		}
		return userManager;
	}

	public void createUser(User user) throws AppException {

		String sqlQuery = "INSERT INTO user (user_id, username, first_name, last_name, email, user_password, user_status) VALUES (?,?,?,?,?,?,?)";

		Object[] params = { user.getUserId(), user.getUsername(), user.getFirstName(), user.getLastName(),
				user.getEmail(), user.getUserPassword(), user.getStatus() };

		this.executeWrite(sqlQuery, params);
	}

	public boolean retrieveRequiredUsersForAdmin(String status) throws AppException {

		String sqlQuery = "SELECT user_id FROM user WHERE user_status=?";

		String[] params = { status };

		if (!this.hasResult(sqlQuery, params)) {
			System.out.println("No Records Found");
			return false;
		}

		String[] headers = { "USER ID" };
		this.executeReadAsTable(sqlQuery, headers, params);
		return true;

	}

	public void updateUser(String username, String field, String newValue) throws AppException {

		String sqlQuery = "UPDATE user SET " + field + "= ? WHERE username = ?";
		Object[] param = { newValue, username };
		this.executeWrite(sqlQuery, param);
	}

	public void updateUser(int id, String field, String newValue) throws AppException {

		String sqlQuery = "UPDATE user SET " + field + "= ? WHERE user_id = ?";
		Object[] param = { newValue, id };
		this.executeWrite(sqlQuery, param);
	}

	public boolean isValidUserPassword(String username, String password) throws AppException {
		String sqlQuery = "SELECT username, user_password FROM user WHERE username = ? AND user_password = ?";
		Object[] param = { username, password };

		return this.hasResult(sqlQuery, param);
	}

	public boolean isValidUserId(int userId) throws AppException {
		return this.isPresent("user", "user_id", userId);
	}

	public boolean isValidUserStatus(int id, String status) throws AppException {

		String sqlQuery = "SELECT user_id, user_status FROM user WHERE user_id=? AND user_status=?";

		return this.hasResult(sqlQuery, new Object[] { id, status });
	}

	public boolean isValidUsername(String username) throws AppException {
		return this.isPresent("user", "username", username);
	}

	public int getUserId(String username) throws AppException {

		String sql = "SELECT user_id from user WHERE username =?";

		return this.getQueryNumber(sql, new Object[] { username });

	}

	public String getUsername(int userId) throws AppException {

		String sql = "SELECT username from user WHERE user_id =?";

		return this.getString(sql, new Object[] { userId });

	}

	public boolean isValidUserStatus(String username) throws AppException {
		String sqlQuery = "SELECT username, user_status FROM user WHERE username=? AND user_status=?";

		return this.hasResult(sqlQuery, new Object[] { username, "active" });
	}

}
