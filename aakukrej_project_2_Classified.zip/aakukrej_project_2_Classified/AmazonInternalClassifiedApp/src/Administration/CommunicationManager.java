package Administration;

import exceptionHandling.AppException;
import resources.Communication;

public class CommunicationManager extends DefaultExecutor {

	private static CommunicationManager communicationManager;

	public static CommunicationManager getInstance() {
		if (communicationManager == null) {
			communicationManager = new CommunicationManager();
		}
		return communicationManager;
	}

	public boolean createCommunication(Communication communication) throws AppException {
		String sqlQuery = "INSERT INTO communication (communication_id, classified_id, sender, receiver, message, status, sender_type, time) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
		Object[] params = { communication.getCommunicationId(), communication.getClassifiedId(),
				communication.getSender(), communication.getReceiver(), communication.getMessage(),
				communication.getStatus(), communication.getSenderType(), communication.getTime() };

		this.executeWrite(sqlQuery, params);
		return true;
	}

	public boolean updateMessageStatus(int id, String field, String newValue) throws AppException {

		String sqlQuery = "UPDATE communication SET " + field + " = ? WHERE communication_id = ?";

		Object param[] = { newValue, id };

		this.executeWrite(sqlQuery, param);

		return true;
	}

	public boolean updateSenderType(int id, String field, String newValue) throws AppException {

		String sqlQuery = "UPDATE communication SET " + field + " = ? WHERE communication_id = ?";

		Object param[] = { newValue, id };

		this.executeWrite(sqlQuery, param);

		return true;
	}

	public String getSenderName(int id) throws AppException {

		String sqlQuery = "SELECT sender FROM communication WHERE communication_id = ?";

		Object param[] = { id };

		return this.getString(sqlQuery, param);
	}

	public String getReceiverName(int id) throws AppException {

		String sqlQuery = "SELECT receiver FROM communication WHERE communication_id = ?";

		Object param[] = { id };

		return this.getString(sqlQuery, param);

	}

	public String getSenderType(int id) throws AppException {

		String sqlQuery = "SELECT sender_type FROM communication WHERE communication_id = ?";

		Object param[] = { id };

		return this.getString(sqlQuery, param);

	}

	public String getCommunicationStatus(int messageId) throws AppException {
		String sqlQuery = "SELECT status FROM communication WHERE communication_id = ?";

		Object param[] = { messageId };

		return this.getString(sqlQuery, param);

	}

	public int getClassifiedId(int id) throws AppException {

		String sqlQuery = "SELECT classified_id FROM communication WHERE communication_id = ?";

		return this.getQueryNumber(sqlQuery, new Object[] { id });
	}

	public boolean isValidMessage(int id) throws AppException {
		return this.isPresent("communication", "communication_id", id);
	}

	public boolean isValidReadMessagesForUser(String username) throws AppException {
		String sqlQuery = "SELECT communication_id, sender_type, sender, time " + "FROM communication "
				+ "WHERE receiver = ? AND status = ? " + "ORDER BY time";

		Object[] param = { username, "read" };

		if (!this.hasResult(sqlQuery, param)) {
			System.out.println("\nNo Message Found!");
			return false;
		}

		return true;
	}

	public boolean retrieveReadMessagesForUser(String username) throws AppException {
		String sqlQuery = "SELECT communication_id, sender_type, sender, time " + "FROM communication "
				+ "WHERE receiver = ? AND status = ? " + "ORDER BY time";

		Object[] param = { username, "read" };

		if (!this.hasResult(sqlQuery, param)) {
			System.out.println("\nNo Message Found!");
			return false;
		}

		String[] headers = { "MESSAGE ID", "TYPE", "SENDER", "TIME" };

		executeReadAsTable(sqlQuery, headers, param);

		return true;

	}

	public boolean isValidUneadMessagesForUser(String username) throws AppException {
		String sqlQuery = "SELECT communication_id, sender_type, sender, time " + "FROM communication "
				+ "WHERE receiver = ? AND status = ? " + "ORDER BY time";

		Object[] param = { username, "unread" };

		if (!this.hasResult(sqlQuery, param)) {
			System.out.println("\nNo Message Found!");
			return false;
		}

		return true;
	}

	public boolean retrieveUneadMessagesForUser(String username) throws AppException {
		String sqlQuery = "SELECT communication_id, sender_type, sender, time " + "FROM communication "
				+ "WHERE receiver = ? AND status = ? " + "ORDER BY time";

		Object[] param = { username, "unread" };

		if (!this.hasResult(sqlQuery, param)) {
			System.out.println("\nNo Unread Message Found!");
			return false;
		}

		String[] headers = { "ID", "TYPE", "SENDER", "TIME" };

		executeReadAsTable(sqlQuery, headers, param);

		return true;

	}

	public boolean isValidSentMessages(String username) throws AppException {

		String sqlQuery = "SELECT communication_id, receiver, time " + "FROM communication " + "WHERE sender = ? "
				+ "ORDER BY time";

		Object[] params = { username };

		return this.hasResult(sqlQuery, params);

	}

	public boolean retrieveSentMessages(String username) throws AppException {

		String sqlQuery = "SELECT communication_id, receiver, time " + "FROM communication " + "WHERE sender = ? "
				+ "ORDER BY time";

		Object[] params = { username };

		if (!this.hasResult(sqlQuery, params)) {
			System.out.println("\nNo Sent Message Found!");
			return false;
		}
		String[] headers = { "ID", "SENT TO", "TIME" };

		this.executeReadAsTable(sqlQuery, headers, params);

		return true;

	}

	public boolean retrieveMessageBody(int id) throws AppException {
		String sqlQuery = "SELECT classified_id, message " + "FROM communication " + "WHERE communication_id = ? ";

		String[] headers = { "PRODUCT ID", "MESSAGE" };

		Object[] params = { id };

		this.executeRead(sqlQuery, headers, params);

		return true;

	}

	public boolean isMessageRead(int messageId) throws AppException {

		String sqlQuery = "SELECT * from communication WHERE communucation_id = ? AND status = ? ";

		Object[] params = { messageId, "read" };

		return this.hasResult(sqlQuery, params);
	}

}
