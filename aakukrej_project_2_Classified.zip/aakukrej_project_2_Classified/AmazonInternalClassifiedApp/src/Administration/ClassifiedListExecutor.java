package Administration;

import exceptionHandling.AppException;
import resources.ClassifiedList;

public class ClassifiedListExecutor extends DefaultExecutor {

	private static ClassifiedListExecutor classifiedCategoryManager;

	public static ClassifiedListExecutor getInstance() {
		if (classifiedCategoryManager == null) {
			classifiedCategoryManager = new ClassifiedListExecutor();
		}
		return classifiedCategoryManager;
	}

	public void addCategory(ClassifiedList category) throws AppException {

		String sqlQuery = "INSERT INTO category (category_id, category_name) VALUES (?,?)";

		Object[] params = { category.getCategoryId(), category.getCategoryName() };

		this.executeWrite(sqlQuery, params);
	}

	public boolean isValidCategory(int categoryId) throws AppException {
		return this.isPresent("category", "category_id", categoryId);
	}

	public String getCategoryName(int id) throws AppException {

		String sqlQuery = "SELECT category_name FROM category WHERE category_id = ?";
		Object[] param = new Object[] { id };

		return this.getString(sqlQuery, param);
	}

	public boolean viewCategory(int id) throws AppException {

		String sqlQuery = "SELECT * FROM category WHERE category_id = ?";

		if (!this.hasResult(sqlQuery, new Object[] { id })) {
			System.out.println("No available Records found");
			return false;
		}

		String[] headers = { "ID", "CATEGORY" };
		this.executeRead(sqlQuery, headers, new Object[] { id });

		return true;
	}

	public boolean viewAllCategories() throws AppException {

		String sqlQuery = "SELECT * FROM category";

		if (!this.hasResult(sqlQuery, new Object[] {})) {
			System.out.println("No available Records found");
			return false;
		}

		String[] headers = { "ID", "CATEGORY" };
		this.executeReadAsTable(sqlQuery, headers, new Object[] {});

		return true;
	}

	public boolean updateCategory(int classifiedId, String field, String newValue) throws AppException {

		String sqlQuery = "UPDATE category SET " + field + "= ? WHERE category_id = ?";
		Object[] params = { newValue, classifiedId };

		this.executeWrite(sqlQuery, params);

		return true;
	}

	public boolean removeCategory(int categoryId) throws AppException {
		String sqlQuery = "DELETE FROM category WHERE category_id=?";
		Object[] params = { categoryId };

		this.executeWrite(sqlQuery, params);
		return true;
	}

}