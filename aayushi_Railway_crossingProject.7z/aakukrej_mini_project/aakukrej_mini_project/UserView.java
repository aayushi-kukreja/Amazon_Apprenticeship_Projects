package view;
import java.util.Scanner;
import controller.UserController;
import model.User;
import util.IntInput;

public class UserView extends View {
    public UserView(Scanner uip) {
        super(uip);
    }

    public void run() {
        int option;
        boolean shouldRun = true;
        System.out.println("\033[H\033[2J");
        while(shouldRun) {
            System.out.println("Railway crossing application");
            System.out.println("=============================");
            System.out.println("\nOption:\n1. Login User\n2. Register User\n3. Exit");
            System.out.print("Select option: ");
            option = IntInput.getInt(uip, 1, 3);

            if(option == -1) {
                uip.nextLine();
                continue;
            }

            switch(option) {
                case 1: login();
                    break;
                case 2: register(1); 
                    break;
                case 3: shouldRun = false;
                    System.out.println("exiting application"); 
                    break;
                default: 
                    System.err.println("invalid option");
            }
        }
    }

    String[] login_inputs() {
        String[] inputs = new String[2];
        System.out.println("Login Page");
        System.out.println("======================");
        System.out.print("Enter email: ");
        inputs[0] = uip.nextLine();
        System.out.print("Enter Password: ");
        inputs[1] = uip.nextLine();
        return inputs;
    }

    String[] register_inputs() {
        String[] inputs = new String[3];
        System.out.println("Register Page");
        System.out.println("======================");
        System.out.print("Enter name: ");
        inputs[0] = uip.nextLine();
        System.out.print("Enter email: ");
        inputs[1] = uip.nextLine();
        System.out.print("Enter password: ");
        inputs[2] = uip.nextLine();
        return inputs;
    }

    public void login() {
        String[] inputs = login_inputs();
        for(String x: inputs) {
            if(x.equals("")) {
                System.out.println("inputs should not be empty");
                return;
            }
        }
        User ucc = UserController.loginUser(inputs[0], inputs[1]);

        if(ucc == null) {
            return;
        }

        switch(ucc.type) {
            case 3:
                AdminView admin = new AdminView(uip);
                admin.run();
                break;
            default:
                CrossingView crossing = new CrossingView(uip);
                crossing.run();
                break;
        }
    }

    public void register(int type) {
        if(type == 3) System.out.println("Admin Registration");
        String[] inputs = register_inputs();
        for(String x : inputs) {
            if(x.equals("")) {
                System.out.println("inputs should not be empty");
                return;
            }
        }
        UserController.registerUser(inputs[0], inputs[1], inputs[2], type);
    }
}
