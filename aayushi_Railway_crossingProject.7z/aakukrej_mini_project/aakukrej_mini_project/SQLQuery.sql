CREATE DATABASE Railway;

create table railwaycrossing
( 
Crossing_Name nvarchar(20) primary key,
Crossing_Address nvarchar(50) NOT NULL,
Crossing_Landmark nvarchar(50),
Time_Schedule varchar(10) not null,
Crossing_Incharge nvarchar(20) not null,
Crossing_Status int not null
); 

create table govtlogin
( 
Name varchar(20) not null,
User_Name nvarchar(20) primary key,
Password nvarchar(50) not null
);

create table userlogin
( 
Name varchar(20) not null,
User_Name nvarchar(20) primary key,
Password nvarchar(50) not null
);