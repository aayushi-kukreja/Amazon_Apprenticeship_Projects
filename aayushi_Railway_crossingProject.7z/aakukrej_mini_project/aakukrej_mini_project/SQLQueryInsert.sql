
insert into railwaycrossing(Crossing_Name,Crossing_Address,Crossing_Landmark,Time_Schedule,Crossing_Incharge,Crossing_Status)
values('a','123, abc street, new delhi, 110003','JLN','09-10','C',1);

insert into railwaycrossing(Crossing_Name,Crossing_Address,Crossing_Landmark,Time_Schedule,Crossing_Incharge,Crossing_Status)
values('Seva Nagar','Seva Nagar, MB Road, New Delhi, 110003','JLN','11-12','Chandan',0);

insert into railwaycrossing(Crossing_Name,Crossing_Address,Crossing_Landmark,Time_Schedule,Crossing_Incharge,Crossing_Status)
values('Old Delhi','Purana Qila, Mathura Road, Delhi, 110006','Lal Qila','13-14','Aman',1);

insert into railwaycrossing(Crossing_Name,Crossing_Address,Crossing_Landmark,Time_Schedule,Crossing_Incharge,Crossing_Status)
values('Shahdara','Shahdara, CA Road, Delhi, 110048','Yamuna','23-24','Akash',0);


insert into govtlogin(Name, User_Name, Password)
values('Alok','28al@gmail.com','Qwe123!@#');

insert into govtlogin(Name, User_Name, Password)
values('Adi','21ad@gmail.com','Qwe123!@#');

insert into govtlogin(Name, User_Name, Password)
values('Dee','dee@gmail.com','Qwe123!@#');

insert into govtlogin(Name, User_Name, Password)
values('Lll','ll@gmail.com','Qwe123!@#');



insert into userlogin(Name, User_Name, Password)
values('Ama','ama@gmail.com','Qwe123!@#');

insert into userlogin(Name, User_Name, Password)
values('Sri','sri@gmail.com','Qwe123!@#');

insert into userlogin(Name, User_Name, Password)
values('Muskan','muskan@gmail.com','Qwe123!@#');

insert into userlogin(Name, User_Name, Password)
values('Arjun','arjun@gmail.com','Qwe123!@#');
