package view;

import java.util.*;
import controller.*;
import model.User;
import util.IntInput;

public class CrossingView extends View {
    public CrossingView(Scanner uip) {
        super(uip);
    }

    public void run() {
        boolean shouldRun = true;
        int option;
        System.out.println("\033[H\033[2J");
        while(shouldRun) {
            System.out.println("Railway crossings Page");
            System.out.println("======================");
            System.out.println("Options:");
            System.out.println("\n1. List Crossing\n2. Search Crossing\n3. List Crossing sorted\n4. Logout");
            System.out.print("Select option: ");

            option = IntInput.getInt(uip, 1, 4);
            if(option == -1) continue;

            switch(option) {
                case 1:
                    CrossingController.listCrossings();
                    break;
                case 2:
                    searchCrossing();
                    break;
                case 3:
                    crossingSorted();
                    break;
                case 4:
                    shouldRun = false;
                    break;
            }
            if(option != 4) {
                System.out.println("Press enter to Continue");
                uip.nextLine();
            }
        }
    }

    public void crossingSorted() {
        int option;
        List<String> schdle;
        System.out.print("Enter Crossing id:");
        int crsname = IntInput.getInt(uip, 1, Integer.MAX_VALUE);
        if(crsname == -1) {
            System.out.println("id should be an integer");
            return;
        }
        System.out.println("Select sorting options:");
        System.out.println("1. Ascending from opening");
        System.out.println("2. Ascending from closing");
        System.out.println("3: Descending from opening");
        System.out.println("4: Descending from closing");

        System.out.print("Enter Option: ");

        option = IntInput.getInt(uip, 1, 4);
        if(option == -1) {
            System.out.println("invalid sort option");
            return;
        }

        switch(option) {
            case 1:
                schdle = CrossingController.getSchedule(crsname, 1, 1);
                printSchedule(schdle);
                break;
            case 2:
                schdle = CrossingController.getSchedule(crsname, 1, 2);
                printSchedule(schdle);
                break;
            case 3:
                schdle = CrossingController.getSchedule(crsname, 2, 1);
                printSchedule(schdle);
                break;
            case 4:
                schdle = CrossingController.getSchedule(crsname, 2, 2);
                printSchedule(schdle);
                break;
        }
    }

    public void printSchedule(List<String> data) {
        if(data != null) {
            data.forEach(k -> {
                System.out.println("Schedule: " + k);
            });
        }
    }

    public void searchCrossing() {
        System.out.print("Enter search string: ");
        String searchString = uip.nextLine();
        if(searchString.length() == 0) {
            System.out.print("empty search query not allowed");
            return;
        }
        System.out.println("Results:");
        CrossingController.search(searchString);
    }

    public void addCrossing() {
        String[] inputs = new String[4];
        System.out.println("Add crossing Page");
        System.out.println("======================");
        System.out.print("Enter name: ");
        inputs[0] = uip.nextLine();
        System.out.print("Enter address: ");
        inputs[1] = uip.nextLine();
        System.out.print("Enter landmark: ");
        inputs[2] = uip.nextLine();
        System.out.print("Enter user email of incharge: ");
        inputs[3] = uip.nextLine();
        User incharge = UserController.getUser(inputs[3]);
        if(incharge == null) {
            System.out.println("Incharge not found in users. Create new user");
            UserView uvc = new UserView(uip);
            uvc.register(2);
        }
        CrossingController.addCrossing(inputs[0], inputs[1], inputs[2], inputs[3]);
    }

    public void deleteCrossing() {
        System.out.print("Enter id of crossing that you want to delete: ");
        int crsname = IntInput.getInt(uip, 1, Integer.MAX_VALUE);

        if(crsname == -1) {
            System.out.println("invalid sort option");
            return;
        }

        CrossingController.deleteCrossing(crsname);
        System.out.println("Crossing " + crsname + " is deleted");
    }

    public void updateCrossing() {
        System.out.print("Enter id of crossing whose status that you want to update: ");
        int crsname = IntInput.getInt(uip, 1, Integer.MAX_VALUE);

        if(crsname == -1) {
            System.out.println("invalid sort option");
            return;
        }

        System.out.print("Enter Status(True or False): ");
        Boolean status = uip.nextBoolean();
        CrossingController.updateCrossingStatus(crsname, status);
        System.out.println("Status of crossing: " + crsname + "updated successfully");
    }

    public void addSchedules() {
        System.out.print("Enter id of crossing: ");
        int crsname = IntInput.getInt(uip, 1, Integer.MAX_VALUE);

        if(crsname == -1) return;

        System.out.println("Schedule to be entered in 19:00-19:15 format.");
        System.out.println("Press enter without any input to stop adding new schedules");

        while(true) {
            System.out.print("Enter time: ");
            String dlt = uip.nextLine();
            if(dlt.equals("")) break;
            if(dlt.matches("^([0-1]?[0-9]|2[0-3]):[0-5][0-9]-([0-1]?[0-9]|2[0-3]):[0-5][0-9]$")){
                if(!CrossingController.addSchedule(crsname, dlt)) {
                    break;
                }
            } else {
                System.out.println("Invalid format");
            }
        }

    }
}
