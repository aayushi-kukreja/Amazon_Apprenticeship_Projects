create table users(
	email nvarchar(100) primary key,
	name nvarchar(50) not null,
	password nvarchar(100) not null,
	type tinyint default 1
);

create table crossings(
	id bigint primary key identity(1,1),
	name nvarchar(50) not null,
	address nvarchar(100),
	landmark nvarchar(50),
	incharge nvarchar(100) foreign key references users(email) ON DELETE cascade unique,
	status bit default 0,
	schedules nvarchar(max)
);

-- test data
insert into users ( email, name, password, type) values ('ukaye0@bandcamp.com', 'Arkansas Alumroot', 'GXHw9FfCW', 1), 
( 'aaindriu1@apache.org', 'Douglas'' Mesamint', 'Dke5r2Qn8hv', 2), 
('melement2@bandcamp.com', 'White Rocklettuce', 'HFtzysKm', 3), 
('wgravener3@booking.com', 'Asphodel', 'ntpj8q', 1), 
('lgres4@baidu.com', 'Fivebract Chinchweed', '5mIILSSR', 2), 
('eferries6@yahoo.co.jp', 'Zephyrlily', '5VmILYo', 2);

insert into crossings (name, address, landmark, incharge, status, schedules) values ('Shenandoah Pore Lichen', '01435 Summer Ridge Trail', 'array', 'aaindriu1@apache.org', 1, '18:00-18:13;19:30-19:35;15:21-15:24'),
('Gifford','8000 Logan Plaza','Springs','eferries6@yahoo.co.jp',1,'14:00-15:20;16:30-17:38;20:54-20:59'),
('Barret','79286 Grayhawk Plaza','Alpine','lgres4@baidu.com',1,'15:00-15:20;18:30-18:38;20:54-20:57');