package view;
import java.util.Scanner;
import controller.*;
import util.IntInput;

public class AdminView extends View {
    CrossingView cross_view;
    public AdminView(Scanner uip) {
        super(uip);
        cross_view = new CrossingView(uip);
    }

    public void run() {
        boolean shouldRun = true;
        int option;
        System.out.println("\033[H\033[2J");
        while(shouldRun) {
            System.out.println("Admin Page");
            System.out.println("======================");
            System.out.println("\nOption:\n1. List Crossing\n2. Add Crossing\n3. Delete Crossing\n4. Search Crossing\n5. Update Crossing Status\n6. Add Schedules\n7. List Users\n8. Logout");
            System.out.print("Select option: ");

            option = IntInput.getInt(uip, 1, 8);
            if(option == -1) continue;

            switch(option) {
                case 1:
                    CrossingController.listCrossings();
                    break;
                case 2:
                    cross_view.addCrossing();
                    break;
                case 3:
                    cross_view.deleteCrossing();
                    break;
                case 4:
                    cross_view.searchCrossing();
                    break;
                case 5:
                    cross_view.updateCrossing();
                    break;
                case 6:
                    cross_view.addSchedules();
                    break;
                case 7:
                    UserController.listUsers();
                    break;
                case 8:
                    shouldRun = false;
                    break;
            }
            if(option != 8) {
                System.out.println("Press enter to Continue");
                uip.nextLine();
            }
        }
    }

}
