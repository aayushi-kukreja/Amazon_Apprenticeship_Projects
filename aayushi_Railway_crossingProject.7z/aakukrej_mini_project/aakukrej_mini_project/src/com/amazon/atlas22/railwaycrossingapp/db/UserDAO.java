package com.amazon.atlas22.railwaycrossingapp.db;


import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

import com.amazon.atlas22.railwaycrossingapp.model.User;

public class UserDAO implements DAO <User> {

	DB db = DB.getDB();
	
	public int insert(User object) {
        String sql = "INSERT INTO Users(name, email, password, userType) VALUES ('"+object.getName()+"', '"+object.getEmail()+"', '"+object.getPassword()+"', "+object.getUserType()+")"; 
		return db.executeSQL(sql);
	}

	public int update(User object) {
		
		return 0;
	}

	public int delete(User object) {
		// TODO Auto-generated method stub
		return 0;
	}

	public List<User> query() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	public User queryOne(User object) {
		
		User user = new User();
		
		String sql = "SELECT * from Users WHERE email = '"+object.getEmail()+"' AND password = '"+object.getPassword()+"'";
		ResultSet set = db.executeRetrieveQuery(sql);
		
		try {
			if(set.next()) {
				user.setName(set.getString("name"));
				user.setEmail(set.getString("email"));
				user.setPassword(set.getString("password"));
				user.setUserType(set.getInt("userType"));
			}
		} catch (Exception e) {
			System.err.println("Something Went Wrong: "+e);
		}
		
		return user;
		
	}

	
	public boolean set(Object object) {
		// TODO Auto-generated method stub
		return false;
	}

	
	public boolean delete(Object object) {
		// TODO Auto-generated method stub
		return false;
	}

	
	public Map<String, ?> retrieve(Object object) {
		// TODO Auto-generated method stub
		return null;
	}


	public Object retrieve(String key) {
		// TODO Auto-generated method stub
		return null;
	}
	

}