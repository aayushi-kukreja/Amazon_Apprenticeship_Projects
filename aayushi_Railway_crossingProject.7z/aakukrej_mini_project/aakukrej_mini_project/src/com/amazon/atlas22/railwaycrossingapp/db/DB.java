package com.amazon.atlas22.railwaycrossingapp.db;

import java.util.LinkedHashMap;
import java.util.Map;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import com.amazon.atlas22.railwaycrossingapp.model.RailwayCrossing;
import com.amazon.atlas22.railwaycrossingapp.model.User;

public class DB {

	private LinkedHashMap<String, User> users = new LinkedHashMap<String, User>();

	private LinkedHashMap<String, RailwayCrossing> crossings = new LinkedHashMap<String, RailwayCrossing>();

	private static DB db;


	// Singleton Design Pattern
	public static DB getInstance() {
		if (db == null) {
			db = new DB();
		}

		return db;
	}

	void populateAdminUsers() {
		User user1 = new User("Aayushi", "aayushi@example.com", "aayushi123", 2);
		User user2 = new User("Kirti", "Kirti@example.com", "Kirti123", 2);
		set(user1);
		set(user2);
	}

	// Performs both insert and update
	public boolean set(Object object) {
		if (object instanceof User) {
			User user = (User) object;
			users.put(user.getEmail(), user);
			return true;
		} else {
			RailwayCrossing crossing = (RailwayCrossing) object;
			crossings.put(crossing.getPersonInCharge().getEmail(), crossing);
			return true;
		}
	}

	public boolean delete(Object object) {
		if (object instanceof User) {
			User user = (User) object;
			User remove = users.remove(user.getEmail());
			if (remove != null) {
				return true;
			}
			return false;
		} else {
			RailwayCrossing crossing = (RailwayCrossing) object;
			System.out.println();
			RailwayCrossing remove = crossings.remove(crossing.getPersonInCharge().getEmail());
			if (remove != null) {
				return true;
			}
			System.out.println("RC List " + remove);
			return false;
		}
	}

	public Map<String, ?> retrieve(Object object) {
		if (object instanceof User) {
			return users;
		} else {
			return crossings;
		}
	}

	public Object retrieve(String key) {

		if (users.containsKey(key)) {
			return users.get(key);
		} else if (crossings.containsKey(key)) {
			return crossings.get(key);
		} else {
			return null;
		}
	}

	public int getUserCount() {
		return users.size();
	}

	public int getCrossingsCount() {
		return crossings.size();
	}

	private Connection connection;
	
	// Singleton Design Pattern
	private DB() {
		populateAdminUsers();

		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			System.out.println("[DB] Driver Loaded..");
			createConnection();
		} catch (Exception e) {
			System.err.println("[DB] [Driver] Something Went Wrong: "+e);
		}
		
	}
	
	public static DB getDB() {
		return db;
	}
	
	// Troubleshoot: https://learn.microsoft.com/en-us/answers/questions/499956/jdbc-connection-issue.html
	// 				 Enable TCP/IP Service in SQL Server Configuration and Restart
	private void createConnection() {
		try {
			
			String url = "jdbc:sqlserver://learnoa-atlas-server.database.windows.net:1433;database=db-atlas22;user=atlas@learnoa-atlas-server;password=@tl@s123;encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;";			
			connection = DriverManager.getConnection(url);
			System.out.println("[DB] Connection Created...");
			
		} catch (Exception e) {
			System.err.println("[DB] [Connection] Something Went Wrong: "+e);
		}
	}
	
	// WRITE OPERATION (Insert/Update/Delete)
	public int executeSQL(String sql) {
		
		int result = 0;
		
		try {
			Statement stmt = connection.createStatement();
			result = stmt.executeUpdate(sql);
			System.out.println("[DB] SQL Statement Executed...");
		} catch (Exception e) {
			System.err.println("[DB] [Execute SQL] Something Went Wrong: "+e);
		}
		
		return result;
	}
	
	// READ 
	public ResultSet executeRetrieveQuery(String sql) {
		
		// ResultSet holds Table Data
		ResultSet set = null;
		
		try {
			
			Statement stmt = connection.createStatement();
			
			set = stmt.executeQuery(sql);
			
			System.out.println("[DB] SQL Statement Executed...");
		} catch (Exception e) {
			System.err.println("[DB] [Execute SQL] Something Went Wrong: "+e);
		}
		
		return set;
		
	}
	
	public void closeConnection() {
		try {
			connection.close();
			System.out.println("[DB] Connection Closed..");
		} catch (Exception e) {
			System.err.println("[DB] [Connection] Something Went Wrong: "+e);
		}
	}
}


