package com.amazon.atlas22.railwaycrossingapp;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

import com.amazon.atlas22.railwaycrossingapp.controller.RailwayCrossingController;
import com.amazon.atlas22.railwaycrossingapp.model.RailwayCrossing;
import com.amazon.atlas22.railwaycrossingapp.model.User;

public class GovernmentApp {

	RailwayCrossingController controller;
	Scanner scanner;

	private static GovernmentApp app;

	public static GovernmentApp getInstance() {
		if (app == null) {
			app = new GovernmentApp();
		}
		return app;
	}

	private GovernmentApp() {
		controller = RailwayCrossingController.getInstance();
		scanner = new Scanner(System.in);
	}

	void startGovernmentApp() {

		System.out.println("--------------------------------");
		System.out.println("Welcome Admin User");
		System.out.println("Proceed to Login");
		System.out.println("---------------------------------");

		login();

	}

	void login() {
		User user = new User();

		// Empty Next Line for Scanner Issue

		System.out.println("Enter Admin Email: ");
		user.setEmail(scanner.nextLine());

		System.out.println("Enter Admin Password: ");
		user.setPassword(scanner.nextLine());

		if (controller.loginUser(user)) {
			System.out.println(user.getName() + "You have Logged In Successfully..");
			System.out.println("Navigating to the Government Railway Crossing Application");

			// Navigate to Home
			home();
		} else {
			System.err.println("Something Went Wrong. Please Try Again");
		}
	}

	void home() {

		while (true) {

			System.out.println("------------------------------");
			System.out.println("Welcome to Government Railway Crossing Home");
			System.out.println("We have " + controller.getCrossingsCount() + " Crossings in the DataBase");
			System.out.println("1: Add Railway Crossing");
			System.out.println("2: List Railway Crossings");
			System.out.println("3: Search Railway Crossings");
			System.out.println("4: Update Railway Crossing status");
			System.out.println("5: Delete Railway Crossing");
			System.out.println("6: Close Goverment Application");
			System.out.println("---------------------------------");

			int choice = scanner.nextInt();
			switch (choice) {

			case 1:
				addCrossing();
				break;

			case 2:
				listCrossings();
				break;

			case 3:
				searchCrossing();
				break;
			case 4:
				updateStatusOfCrossing();
				break;
			case 5:
				deleteCrossing();

				break;

			case 6:
				System.out.println("Thank You for using Railway Crossing App");
				break;

			default:
				System.err.println("Invalid Choice");
			}

			if (choice == 6) {
				break;
			}
		}
	}

	void addCrossing() {

		// Empty Next Line for Scanner Issue
		scanner.nextLine();

		User user = new User();
		RailwayCrossing crossing = new RailwayCrossing();

		System.out.println("Enter Person InCharge Details");

		System.out.println("Enter Name: ");
		user.setName(scanner.nextLine());

		System.out.println("Enter Email: ");
		user.setEmail(scanner.nextLine());

		System.out.println("Enter Password: ");
		user.setPassword(scanner.nextLine());

		user.setUserType(3);

		System.out.println("Enter Railway Crossing Details");

		System.out.println("Enter Railway Crossing Name: ");
		crossing.setName(scanner.nextLine());

		System.out.println("Enter Railway Crossing Address: ");
		crossing.setAddress(scanner.nextLine());

		System.out.println("Enter Railway Crossing Schedule: ");
		String scheduleKey = scanner.nextLine();
		String scheduleValue = scanner.nextLine();
		LinkedHashMap<String, String> l = new LinkedHashMap<>();
		l.put(scheduleKey, scheduleValue);
		crossing.setSchedules(l);
//		crossing.getSchedules().put(scheduleKey, scheduleValue);
		crossing.setPersonInCharge(user);

		if (controller.addOrUpdateCrossing(crossing)) {
			System.out.println(crossing.getName() + " Added Successfully...");
		} else {
			System.err.println("Something Went Wrong. Please Try Again");

		}
	}

	void listCrossings() {

		Map<String, RailwayCrossing> crossings = (Map<String, RailwayCrossing>) controller.fetchCrossings();
		for (String key : crossings.keySet()) {
			System.out.println(crossings.get(key));
			System.out.println("--------------------------");
		}

	}

	void searchCrossing() {

		// Empty Next Line for Scanner Issue
		scanner.nextLine();

		RailwayCrossing crossing = new RailwayCrossing();

		System.out.println("Enter Railway Crossing Name: ");
		crossing.setName(scanner.nextLine());

		RailwayCrossing searchCrossingsByRCName = controller.searchCrossingsByRCName(crossing);
		if (searchCrossingsByRCName != null && searchCrossingsByRCName.getName() != null) {
			System.out.println(searchCrossingsByRCName.toString());
		} else {
			System.err.println("Railway Crossing Not Found for name " + crossing.getName() + " .Please try again");
		}
	}

	void updateStatusOfCrossing() {

		// Empty Next Line for Scanner Issue
		scanner.nextLine();

		RailwayCrossing crossing = new RailwayCrossing();

		System.out.println("Enter Railway Crossing Name: ");
		crossing.setName(scanner.nextLine());

		System.out.println("Enter 1 for Open and 2 for closing  Railway Crossing : ");

		boolean updateCrossingStatus = controller.updateCrossingStatus(crossing, scanner.nextInt());
		if (updateCrossingStatus == true) {
			System.out.println("Updated RC status successfully for " + crossing.getName());
		} else {
			System.err.println("Something went wrong in updating rc status");

		}
	}

	void deleteCrossing() {
		User user = new User();
		RailwayCrossing crossing = new RailwayCrossing();

		System.out.println("Enter Person Incharge User Details in  Railway crossing for deletion");
		scanner.nextLine();

		System.out.println("Enter Person Incharge Name: ");
		user.setName(scanner.nextLine());

		System.out.println("Enter Person Incharge Email: ");
		user.setEmail(scanner.nextLine());

		user.setUserType(3);

		System.out.println("Enter Railway Crossing Name: ");
		crossing.setName(scanner.nextLine());

		crossing.setPersonInCharge(user);

		if (controller.deleteCrossing(crossing)) {
			System.out.println(crossing.getName() + " Deleted Successfully...");
		} else {
			System.err.println(crossing.getName() + ",Cannot be deleted as Not Found");

		}
	}

}
