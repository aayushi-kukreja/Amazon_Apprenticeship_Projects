package com.amazon.atlas22.railwaycrossingapp.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.amazon.atlas22.railwaycrossingapp.db.DB;
import com.amazon.atlas22.railwaycrossingapp.model.RailwayCrossing;
import com.amazon.atlas22.railwaycrossingapp.model.User;

public class RailwayCrossingController {

	private static RailwayCrossingController controller;

	private RailwayCrossingController() {

	}

	public static RailwayCrossingController getInstance() {
		if (controller == null) {
			controller = new RailwayCrossingController();
		}

		return controller;
	}

	private DB db = DB.getInstance();

	public boolean loginUser(User user) {

		if (user.validate()) {
			User retrievedUser = (User) db.retrieve(user.getEmail());
			if (retrievedUser != null && retrievedUser.getUserType() == 2) {
				// user.setName(retrievedUser.getName());
				return (retrievedUser.getEmail().equalsIgnoreCase(user.getEmail())
						&& retrievedUser.getPassword().equals(user.getPassword()));
			}
		}

		return false;
	}

	public boolean addOrUpdateCrossing(RailwayCrossing crossing) {
		return db.set(crossing);
	}

	public boolean updateCrossingStatus(RailwayCrossing crossing, int status) {
		RailwayCrossing searchCrossingsByRCName = searchCrossingsByRCName(crossing);
		if (searchCrossingsByRCName.getName() != null) {
			searchCrossingsByRCName.setStatus(status);

			return db.set(searchCrossingsByRCName);
		}else {
			System.err.println("Invalid Choice");
		}
		return false;
	}

	public boolean deleteCrossing(RailwayCrossing crossing) {
		boolean result = false;
		try {
			result = db.delete(crossing);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public Map<String, ?> fetchCrossings() {
		return db.retrieve(new RailwayCrossing());
	}

	public RailwayCrossing searchCrossingsByRCName(RailwayCrossing crossing) {
		Map<String, ?> retrieve = db.retrieve(new RailwayCrossing());
		for (Map.Entry<String, ?> p : retrieve.entrySet()) {
			RailwayCrossing rc = (RailwayCrossing) p.getValue();

			if (rc.getName().equals(crossing.getName())) {

				return rc;
			}
		}
		return new RailwayCrossing();
	}

	public int getCrossingsCount() {
		return db.getCrossingsCount();
	}

	public void sortRC() {
		Map<String, RailwayCrossing> retrieve = (Map<String, RailwayCrossing>) db.retrieve(new RailwayCrossing());
		Set<Entry<String, RailwayCrossing>> entrySet2 = retrieve.entrySet();
		ArrayList<Entry<String, RailwayCrossing>> arrayList = new ArrayList<>(entrySet2);

		Collections.sort(arrayList, new Comparator<Entry<String, RailwayCrossing>>() {

			@Override
			public int compare(Entry<String, RailwayCrossing> o1, Entry<String, RailwayCrossing> o2) {
				return o1.getValue().getSchedules().entrySet().stream().findFirst().get().getKey()
						.compareTo(o2.getValue().getSchedules().entrySet().stream().findFirst().get().getKey());
			}
		});

		for (Map.Entry<String, RailwayCrossing> e : arrayList) {
			System.out.println(e.getValue());
		}
//		System.out.println(arrayList);

	}
}
