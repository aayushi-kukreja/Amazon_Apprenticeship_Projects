package view;
import java.util.Scanner;

public abstract class View {
    Scanner uip;
    public View(Scanner uip) {
        this.uip = uip;
    }

    public abstract void run();
}
